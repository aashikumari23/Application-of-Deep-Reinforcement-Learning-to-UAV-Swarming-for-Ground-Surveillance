"""
execution.py
------------
Run the trained UAV swarm on a full example mission.

Flow:
  1. Load trained model weights (search, tracking, obstacle).
  2. Create SwarmEnvironment (with UAV type counts + obstacle params).
  3. Create SwarmController.
  4. At each step:
      a. SC.update() -> assigns/reassigns tasks.
      b. Move targets (step_targets).
      c. Move obstacles (step_obstacles)  <- NEW
      d. Each UAV selects the appropriate sub-agent:
           - If obstacle proximity sensor fires -> ObstacleAgent
           - Else if task == 'tracking'         -> TrackingAgent
           - Else                               -> SearchAgent
      e. The active sub-agent produces (delta_heading, thrust).
      f. env.apply_uav_action() moves the UAV.
      g. logger records UAV states, target states, obstacle states,   <- +obstacles
         events, metrics.
  5. Write final summary CSV.

All LSTM hidden states are maintained per-UAV per-sub-agent across steps.

New parameters accepted by run_execution()
------------------------------------------
uav_type_counts         : dict  e.g. {'default': 4, 'searcher': 2, 'trailer': 2}
obstacle_mobility_prob  : float [0, 1]
obstacle_speed          : float m/s
"""

import os
import math
import numpy as np
import torch
from typing import Dict, Tuple, List, Optional

from environment import (
    SwarmEnvironment, UAVState, TargetState,
    UAV_TURN_RATE, PROXIMITY_RADIUS,
)
from models import (LSTMActorCritic,
                    make_search_agent, make_tracking_agent, make_obstacle_agent)
from swarm_controller import SwarmController
from logger import SwarmLogger
from rewards import search_reward, tracking_reward, obstacle_reward


# ── paths ─────────────────────────────────────────────────────────────────
CHECKPOINT_DIR = 'checkpoints'
LOG_DIR        = 'simulation_data'


# ── hidden-state manager ──────────────────────────────────────────────────

class HiddenStateBank:
    """Keeps one LSTM hidden state per (UAV uid, sub-agent name) pair."""

    def __init__(self, n_uavs: int, models: Dict[str, LSTMActorCritic]):
        self._states: Dict[Tuple[int, str], Tuple] = {}
        for uid in range(n_uavs):
            for name, model in models.items():
                self._states[(uid, name)] = model.init_hidden(1)

    def get(self, uid: int, name: str) -> Tuple:
        return self._states[(uid, name)]

    def set(self, uid: int, name: str, hidden: Tuple):
        self._states[(uid, name)] = hidden

    def reset_uav(self, uid: int, name: str, model: LSTMActorCritic):
        self._states[(uid, name)] = model.init_hidden(1)


# ── sub-agent action selection ────────────────────────────────────────────

@torch.no_grad()
def _get_action(model: LSTMActorCritic,
                obs: np.ndarray,
                hidden: Tuple) -> Tuple[np.ndarray, Tuple]:
    obs_t  = torch.FloatTensor(obs).unsqueeze(0).unsqueeze(0)
    h      = (hidden[0], hidden[1])
    mean, _, new_h = model(obs_t, h)
    std    = model.log_std.exp().expand_as(mean)
    dist   = torch.distributions.Normal(mean, std)
    action = dist.sample().squeeze().numpy()
    return np.clip(action, -1.0, 1.0), new_h


# ── main execution ────────────────────────────────────────────────────────

def run_execution(
        n_uavs:       int  = 8,          # used only if uav_type_counts is None
        n_targets:    int  = 5,
        max_steps:    int  = 750,
        seed:         int  = 99,
        checkpoint_dir: str = CHECKPOINT_DIR,
        out_dir:      str = LOG_DIR,
        # ── new parameters ───────────────────────────────────────────────
        uav_type_counts:        Optional[Dict[str, int]] = None,
        obstacle_mobility_prob: float = 0.0,
        obstacle_speed:         float = 5.0,
) -> str:
    """
    Runs the full swarm mission with trained models.
    Returns the path to the output directory.
    """

    # ── Load trained models ───────────────────────────────────────────────
    search_model   = make_search_agent()
    tracking_model = make_tracking_agent()
    obstacle_model = make_obstacle_agent()

    for name, model, fname in [
        ('search',   search_model,   'search_agent_best.pt'),
        ('tracking', tracking_model, 'tracking_agent_best.pt'),
        ('obstacle', obstacle_model, 'obstacle_agent_best.pt'),
    ]:
        path = os.path.join(checkpoint_dir, fname)
        if os.path.exists(path):
            model.load_state_dict(torch.load(path, map_location='cpu'))
            print(f"[Exec] Loaded {name} weights from {path}")
        else:
            print(f"[Exec] WARNING: {path} not found — using random weights for {name}")
        model.eval()

    models = {
        'search':   search_model,
        'tracking': tracking_model,
        'obstacle': obstacle_model,
    }

    # ── Environment & Controller ──────────────────────────────────────────
    env = SwarmEnvironment(
        n_uavs                 = n_uavs,
        n_targets              = n_targets,
        seed                   = seed,
        uav_type_counts        = uav_type_counts,
        obstacle_mobility_prob = obstacle_mobility_prob,
        obstacle_speed         = obstacle_speed,
    )

    # Resolve actual UAV count after type expansion
    actual_n_uavs = env.n_uavs

    # Print fleet composition
    type_summary: Dict[str, int] = {}
    for uav in env.uavs:
        type_summary[uav.uav_type] = type_summary.get(uav.uav_type, 0) + 1
    print(f"[Exec] Fleet: {type_summary}")
    n_mobile = sum(1 for o in env.obstacles if o.vx != 0.0 or o.vy != 0.0)
    print(f"[Exec] Obstacles: {len(env.obstacles)} total, "
          f"{n_mobile} mobile (prob={obstacle_mobility_prob}, speed={obstacle_speed} m/s)")

    sc = SwarmController(env, replan_interval=25)

    # ── Logger & hidden states ────────────────────────────────────────────
    os.makedirs(out_dir, exist_ok=True)
    logger = SwarmLogger(out_dir=out_dir)
    hs     = HiddenStateBank(actual_n_uavs, models)

    # Per-UAV consecutive-detection counter
    uav_consec_detect: Dict[int, int] = {u.uid: 0 for u in env.uavs}

    # ── Simulation loop ───────────────────────────────────────────────────
    summary_rows = []

    for step in range(max_steps):

        # 1. SC update (mission planning)
        events = sc.update()
        for ev in events:
            logger.record_event(
                step,
                ev.get('event', 'unknown'),
                uav_id    = ev.get('uav_id'),
                target_id = ev.get('target_id'),
                task_type = ev.get('task_type', ''),
                detail    = str(ev),
            )

        # 2. Move targets
        env.step_targets()

        # 3. Move obstacles (new — no-op if all static)
        env.step_obstacles()

        # 4. Log obstacle positions every step for visualisation
        logger.record_obstacles(step, env.obstacles)

        # 5. UAV actions
        n_collisions = 0
        for uav in env.uavs:

            # ── choose sub-agent ──────────────────────────────────────────
            # Use the UAV's own proximity_radius (via cfg) — already
            # baked into obstacles_in_proximity(); just check the list.
            prox = env.obstacles_in_proximity(uav)
            if prox:
                subagent_name = 'obstacle'
            elif uav.task == 'tracking':
                subagent_name = 'tracking'
            else:
                subagent_name = 'search'

            uav.active_subagent = subagent_name

            # ── build observation ─────────────────────────────────────────
            if subagent_name == 'search':
                obs = env.get_search_obs(uav)

            elif subagent_name == 'tracking':
                tgt = (env.targets[uav.target_id]
                       if uav.target_id is not None
                       and uav.target_id < len(env.targets)
                       else None)
                obs = env.get_tracking_obs(uav, tgt)

            else:  # obstacle
                if uav.task == 'tracking' and uav.target_id is not None:
                    t    = env.targets[uav.target_id]
                    goal = (t.x, t.y)
                elif uav.search_area:
                    sa   = uav.search_area
                    goal = ((sa[0] + sa[2]) / 2, (sa[1] + sa[3]) / 2)
                else:
                    goal = (0.0, 0.0)
                obs = env.get_obstacle_obs(uav, goal)

            # ── inference ─────────────────────────────────────────────────
            hidden = hs.get(uav.uid, subagent_name)
            action, new_hidden = _get_action(models[subagent_name], obs, hidden)
            hs.set(uav.uid, subagent_name, new_hidden)

            # ── apply action ──────────────────────────────────────────────
            env.apply_uav_action(uav,
                                 action[0] * UAV_TURN_RATE,
                                 action[1])

            # ── compute reward for logging ────────────────────────────────
            col = env.collision_occurred(uav)
            if col:
                n_collisions += 1

            if subagent_name == 'search':
                rew = search_reward(uav, env, set(), 1,
                                    False, max_steps, step)

            elif subagent_name == 'tracking':
                tgt = (env.targets[uav.target_id]
                       if uav.target_id is not None
                       and uav.target_id < len(env.targets)
                       else None)
                visible = tgt is not None and tgt in env.targets_in_sensor(uav)
                uav_consec_detect[uav.uid] = (
                    uav_consec_detect[uav.uid] + 1 if visible else 0
                )
                rew = (tracking_reward(uav, tgt, env,
                                       uav_consec_detect[uav.uid],
                                       30, False, step, max_steps)
                       if tgt is not None else 0.0)

            else:
                rew = obstacle_reward(uav, env, False, step, max_steps)

            logger.record_uav(step, uav, rew, col)

        # 6. Log targets
        for tgt in env.targets:
            logger.record_target(step, tgt)

        # 7. Log metrics
        logger.record_metrics(step, env, n_collisions)

        # 8. Console progress
        if step % 100 == 0:
            sm    = sc.status_summary()
            n_det = sum(1 for t in env.targets if t.detected)
            print(f"[Exec] Step {step:4d} | "
                  f"Search={sm['n_search']}, Tracking={sm['n_tracking']}, "
                  f"Detected={n_det}/{n_targets} | "
                  f"Collisions this step={n_collisions}")

        # 9. Summary row
        n_det = sum(1 for t in env.targets if t.detected)
        summary_rows.append({
            'step':         step,
            'n_detected':   n_det,
            'n_total':      n_targets,
            'pct_detected': round(n_det / max(n_targets, 1) * 100, 2),
        })

        # 10. Note when all targets are first tracked (continue running)
        if n_det >= n_targets and step > 50:
            all_tracked = all(
                any(u.task == 'tracking' and u.target_id == t.tid
                    for u in env.uavs)
                for t in env.targets
            )
            if all_tracked:
                logger.record_event(step, 'all_targets_tracked',
                                    detail='Mission objective achieved')
                print(f"[Exec] All targets tracked at step {step}. Continuing…")

    # ── Final flush ───────────────────────────────────────────────────────
    logger.flush()
    logger.close()

    import csv as _csv
    summary_path = os.path.join(out_dir, 'execution_summary.csv')
    with open(summary_path, 'w', newline='') as f:
        w = _csv.DictWriter(f, fieldnames=['step', 'n_detected',
                                           'n_total', 'pct_detected'])
        w.writeheader()
        w.writerows(summary_rows)

    print(f"\n[Exec] Execution complete. Output in '{out_dir}/'")
    return out_dir
