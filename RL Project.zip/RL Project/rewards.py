"""
rewards.py
----------
Reward functions for each sub-agent, matching Table 2, 3, 4 in the paper.
"""

import math
from environment import UAVState, TargetState, SwarmEnvironment, SENSOR_RADIUS


# ── Search sub-agent reward ───────────────────────────────────────────────

def search_reward(uav: UAVState,
                  env: SwarmEnvironment,
                  visited_cells: set,
                  total_cells: int,
                  done: bool,
                  max_steps: int,
                  step: int) -> float:
    """
    +1.0  : all cells in task search area visited within time limit
    +0.1  : entering/being in task search area
    -0.25 : leaving task search area
    -0.25 : leaving operation area
    +0.1  : entering operation area (always inside)
    -0.5  : reaching max steps (time-out)
    """
    r = 0.0
    half = env.area / 2.0
    sa   = uav.search_area

    in_area = (
        abs(uav.x) <= half and abs(uav.y) <= half
    )
    if sa:
        in_task = sa[0] <= uav.x <= sa[2] and sa[1] <= uav.y <= sa[3]
    else:
        in_task = False

    if in_task:
        r += 0.05   # per-step incentive to stay
    else:
        r -= 0.25   # penalty for leaving task area

    if not in_area:
        r -= 0.25

    if done and len(visited_cells) >= total_cells:
        r += 1.0     # full coverage bonus

    if step >= max_steps - 1:
        r -= 0.5     # time-out penalty

    # Small per-new-cell reward
    if visited_cells:                # truthy when non-empty
        r += 0.02    # given by caller when a new cell is entered

    return r


def tracking_reward(uav: UAVState,
                    target: TargetState,
                    env: SwarmEnvironment,
                    consecutive_detect: int,
                    detect_threshold: int,
                    done: bool,
                    step: int,
                    max_steps: int) -> float:
    """
    +1.0  : n consecutive steps detecting the target
    +0.1  : target enters sensor coverage this step
    -0.25 : target leaves sensor coverage
    -0.5  : max steps reached
    +0.1  : inside operation area
    -0.25 : left operation area
    """
    r     = 0.0
    half  = env.area / 2.0
    in_area = (abs(uav.x) <= half and abs(uav.y) <= half)

    visible = target in env.targets_in_sensor(uav)

    if visible:
        r += 0.1
        if consecutive_detect >= detect_threshold:
            r += 1.0
    else:
        r -= 0.25

    if not in_area:
        r -= 0.25

    if step >= max_steps - 1:
        r -= 0.5

    return r


def obstacle_reward(uav: UAVState,
                    env: SwarmEnvironment,
                    reached_goal: bool,
                    step: int,
                    max_steps: int) -> float:
    """
    +1.0  : reached goal point
    -0.5  : max steps (timeout)
    -0.5  : collision with agent, edge, or obstacle
    """
    r = 0.0
    if reached_goal:
        r += 1.0
    if env.collision_occurred(uav):
        r -= 0.5
    if step >= max_steps - 1:
        r -= 0.5
    return r
