"""
training.py
-----------
Standalone training loops for each of the three LSTM sub-agents.

Each training function:
  1. Spins up a fresh SwarmEnvironment configured for that task.
  2. Collects rollouts using the current policy.
  3. Calls PPOTrainer.update() when the buffer is full.
  4. Logs per-episode returns and PPO losses to a CSV.
  5. Saves the best model checkpoint.

The trained model weights are returned so the execution script can load them.
"""

import math
import os
import csv
import numpy as np
import torch
from typing import Tuple, Dict

from environment import (
    SwarmEnvironment, UAVState, TargetState,
    AREA_SIZE, SENSOR_RADIUS, UAV_TURN_RATE, DT
)
from models import (make_search_agent, make_tracking_agent, make_obstacle_agent,
                    LSTMActorCritic)
from trainer import PPOTrainer, PPOConfig
from rewards import search_reward, tracking_reward, obstacle_reward


# ── shared helpers ────────────────────────────────────────────────────────

CELL_SIZE = SENSOR_RADIUS          # grid cell = sensor footprint


def _uav_cell(uav: UAVState, sa: Tuple) -> Tuple[int, int]:
    """Return (col, row) of the cell the UAV currently occupies."""
    col = int((uav.x - sa[0]) / CELL_SIZE)
    row = int((uav.y - sa[1]) / CELL_SIZE)
    return col, row


def _total_cells(sa: Tuple) -> int:
    w = sa[2] - sa[0]
    h = sa[3] - sa[1]
    return max(1, int(math.ceil(w / CELL_SIZE)) * int(math.ceil(h / CELL_SIZE)))


def _steer_toward(uav: UAVState, tx: float, ty: float) -> float:
    """Ideal heading delta to point toward (tx, ty), clamped to turn rate."""
    desired = math.atan2(ty - uav.y, tx - uav.x)
    diff    = desired - uav.heading
    # Wrap to [-π, π]
    diff    = (diff + math.pi) % (2 * math.pi) - math.pi
    return float(np.clip(diff, -UAV_TURN_RATE, UAV_TURN_RATE))


def _save_csv(path: str, rows: list, fieldnames: list):
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


# ═══════════════════════════════════════════════════════════════════════════
# 1.  SEARCH SUB-AGENT TRAINING
# ═══════════════════════════════════════════════════════════════════════════

def train_search_agent(
        n_episodes:   int = 300,
        max_steps:    int = 600,
        save_dir:     str = 'checkpoints',
        log_dir:      str = 'logs',
        seed:         int = 0,
) -> LSTMActorCritic:
    """Train the search sub-agent; returns the best model."""

    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(log_dir,  exist_ok=True)

    model   = make_search_agent()
    cfg     = PPOConfig(rollout_steps=256, n_epochs=4)
    trainer = PPOTrainer(model, cfg)

    log_rows  = []
    best_ret  = -1e9
    best_path = os.path.join(save_dir, 'search_agent_best.pt')

    rng = np.random.default_rng(seed)

    for episode in range(1, n_episodes + 1):
        # Minimal env: 1 UAV, 0 targets, few obstacles
        env = SwarmEnvironment(n_uavs=1, n_targets=0,
                               seed=int(rng.integers(0, 99999)),
                               n_obstacles=8)
        uav = env.uavs[0]
        uav.task = 'search'

        visited_cells: set = set()
        total_cells = _total_cells(uav.search_area)

        trainer.reset_hidden()
        ep_return   = 0.0
        losses_list = []

        for step in range(max_steps):
            obs = env.get_search_obs(uav)

            # New cell visited this step?
            cell = _uav_cell(uav, uav.search_area)
            new_cell = cell not in visited_cells
            if new_cell:
                visited_cells.add(cell)

            action, log_prob, value = trainer.select_action(obs)

            # Apply action: action[0] = delta_heading, action[1] = thrust
            env.apply_uav_action(uav, action[0] * UAV_TURN_RATE, action[1])

            done = (len(visited_cells) >= total_cells) or (step == max_steps - 1)

            reward = search_reward(
                uav, env, visited_cells, total_cells,
                done, max_steps, step
            )
            if new_cell:
                reward += 0.02   # additional per-new-cell bonus

            ep_return += reward
            trainer.record_step(obs, action, log_prob, reward, value, done)

            if trainer.should_update():
                last_obs = env.get_search_obs(uav)
                lt = torch.FloatTensor(last_obs).unsqueeze(0).unsqueeze(0)
                h  = (trainer._hidden[0], trainer._hidden[1])
                with torch.no_grad():
                    _, lv, _ = model(lt, h)
                loss_info = trainer.update(last_value=lv.item())
                losses_list.append(loss_info)

            if done:
                break

        # Final update with remaining buffer
        if len(trainer.buffer) > 0:
            loss_info = trainer.update(0.0)
            losses_list.append(loss_info)

        coverage = len(visited_cells) / max(total_cells, 1) * 100.0
        avg_pl   = np.mean([l['policy_loss'] for l in losses_list]) if losses_list else 0
        avg_vl   = np.mean([l['value_loss']  for l in losses_list]) if losses_list else 0

        log_rows.append({
            'episode':       episode,
            'return':        round(ep_return, 4),
            'coverage_pct':  round(coverage, 2),
            'policy_loss':   round(avg_pl, 6),
            'value_loss':    round(avg_vl, 6),
            'steps':         step + 1,
        })

        if ep_return > best_ret:
            best_ret = ep_return
            torch.save(model.state_dict(), best_path)

        if episode % 50 == 0:
            print(f"[Search] Ep {episode:4d} | "
                  f"Return={ep_return:7.2f} | Coverage={coverage:.1f}% | "
                  f"BestRet={best_ret:.2f}")

    _save_csv(
        os.path.join(log_dir, 'search_training_log.csv'),
        log_rows,
        ['episode', 'return', 'coverage_pct', 'policy_loss', 'value_loss', 'steps']
    )

    # Load best weights
    model.load_state_dict(torch.load(best_path, map_location='cpu'))
    print(f"[Search] Training complete. Best return={best_ret:.2f}. "
          f"Weights saved to {best_path}")
    return model


# ═══════════════════════════════════════════════════════════════════════════
# 2.  TRACKING SUB-AGENT TRAINING
# ═══════════════════════════════════════════════════════════════════════════

def train_tracking_agent(
        n_episodes:        int = 300,
        max_steps:         int = 600,
        detect_threshold:  int = 30,   # consecutive steps detecting = success
        save_dir:          str = 'checkpoints',
        log_dir:           str = 'logs',
        seed:              int = 1,
) -> LSTMActorCritic:
    """Train the tracking sub-agent; returns the best model."""

    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(log_dir,  exist_ok=True)

    model   = make_tracking_agent()
    cfg     = PPOConfig(rollout_steps=256, n_epochs=4)
    trainer = PPOTrainer(model, cfg)

    log_rows  = []
    best_ret  = -1e9
    best_path = os.path.join(save_dir, 'tracking_agent_best.pt')

    rng = np.random.default_rng(seed)

    for episode in range(1, n_episodes + 1):
        env = SwarmEnvironment(n_uavs=1, n_targets=1,
                               seed=int(rng.integers(0, 99999)),
                               n_obstacles=6)
        uav = env.uavs[0]
        uav.task = 'tracking'
        uav.target_id = 0
        target = env.targets[0]

        trainer.reset_hidden()
        ep_return         = 0.0
        consecutive_det   = 0
        losses_list       = []

        for step in range(max_steps):
            env.step_targets()    # move target first
            obs = env.get_tracking_obs(uav, target)

            visible = target in env.targets_in_sensor(uav)
            consecutive_det = (consecutive_det + 1) if visible else 0

            action, log_prob, value = trainer.select_action(obs)
            env.apply_uav_action(uav, action[0] * UAV_TURN_RATE, action[1])

            done = step == max_steps - 1

            reward = tracking_reward(
                uav, target, env,
                consecutive_det, detect_threshold,
                done, step, max_steps
            )
            ep_return += reward
            trainer.record_step(obs, action, log_prob, reward, value, done)

            if trainer.should_update():
                last_obs = env.get_tracking_obs(uav, target)
                lt = torch.FloatTensor(last_obs).unsqueeze(0).unsqueeze(0)
                h  = (trainer._hidden[0], trainer._hidden[1])
                with torch.no_grad():
                    _, lv, _ = model(lt, h)
                loss_info = trainer.update(last_value=lv.item())
                losses_list.append(loss_info)

            if done:
                break

        if len(trainer.buffer) > 0:
            loss_info = trainer.update(0.0)
            losses_list.append(loss_info)

        avg_pl = np.mean([l['policy_loss'] for l in losses_list]) if losses_list else 0
        avg_vl = np.mean([l['value_loss']  for l in losses_list]) if losses_list else 0

        log_rows.append({
            'episode':          episode,
            'return':           round(ep_return, 4),
            'consec_detect':    consecutive_det,
            'policy_loss':      round(avg_pl, 6),
            'value_loss':       round(avg_vl, 6),
            'steps':            step + 1,
        })

        if ep_return > best_ret:
            best_ret = ep_return
            torch.save(model.state_dict(), best_path)

        if episode % 50 == 0:
            print(f"[Track]  Ep {episode:4d} | "
                  f"Return={ep_return:7.2f} | ConsecDet={consecutive_det} | "
                  f"BestRet={best_ret:.2f}")

    _save_csv(
        os.path.join(log_dir, 'tracking_training_log.csv'),
        log_rows,
        ['episode', 'return', 'consec_detect', 'policy_loss', 'value_loss', 'steps']
    )

    model.load_state_dict(torch.load(best_path, map_location='cpu'))
    print(f"[Track]  Training complete. Best return={best_ret:.2f}. "
          f"Weights saved to {best_path}")
    return model


# ═══════════════════════════════════════════════════════════════════════════
# 3.  OBSTACLE-AVOIDANCE SUB-AGENT TRAINING
# ═══════════════════════════════════════════════════════════════════════════

def train_obstacle_agent(
        n_episodes: int = 200,
        max_steps:  int = 400,
        save_dir:   str = 'checkpoints',
        log_dir:    str = 'logs',
        seed:       int = 2,
) -> LSTMActorCritic:
    """Train the obstacle-avoidance sub-agent; returns the best model."""

    os.makedirs(save_dir, exist_ok=True)
    os.makedirs(log_dir,  exist_ok=True)

    model   = make_obstacle_agent()
    cfg     = PPOConfig(rollout_steps=256, n_epochs=4)
    trainer = PPOTrainer(model, cfg)

    log_rows  = []
    best_ret  = -1e9
    best_path = os.path.join(save_dir, 'obstacle_agent_best.pt')
    goal_tol  = 60.0   # metres — goal reached if within this distance

    rng = np.random.default_rng(seed)

    for episode in range(1, n_episodes + 1):
        env = SwarmEnvironment(n_uavs=1, n_targets=0,
                               seed=int(rng.integers(0, 99999)),
                               n_obstacles=14)
        uav  = env.uavs[0]
        half = env.area / 2.0
        # Random goal on the opposite side of the area
        gx = float(rng.uniform(-half * 0.8, half * 0.8))
        gy = float(rng.uniform(-half * 0.8, half * 0.8))

        trainer.reset_hidden()
        ep_return   = 0.0
        losses_list = []

        for step in range(max_steps):
            obs = env.get_obstacle_obs(uav, (gx, gy))

            reached = math.hypot(uav.x - gx, uav.y - gy) < goal_tol
            action, log_prob, value = trainer.select_action(obs)
            env.apply_uav_action(uav, action[0] * UAV_TURN_RATE, action[1])

            done   = reached or env.collision_occurred(uav) or step == max_steps - 1
            reward = obstacle_reward(uav, env, reached, step, max_steps)

            ep_return += reward
            trainer.record_step(obs, action, log_prob, reward, value, done)

            if trainer.should_update():
                last_obs = env.get_obstacle_obs(uav, (gx, gy))
                lt = torch.FloatTensor(last_obs).unsqueeze(0).unsqueeze(0)
                h  = (trainer._hidden[0], trainer._hidden[1])
                with torch.no_grad():
                    _, lv, _ = model(lt, h)
                loss_info = trainer.update(last_value=lv.item())
                losses_list.append(loss_info)

            if done:
                break

        if len(trainer.buffer) > 0:
            loss_info = trainer.update(0.0)
            losses_list.append(loss_info)

        avg_pl = np.mean([l['policy_loss'] for l in losses_list]) if losses_list else 0
        avg_vl = np.mean([l['value_loss']  for l in losses_list]) if losses_list else 0
        reached_goal = math.hypot(uav.x - gx, uav.y - gy) < goal_tol

        log_rows.append({
            'episode':      episode,
            'return':       round(ep_return, 4),
            'reached_goal': int(reached_goal),
            'collision':    int(env.collision_occurred(uav)),
            'policy_loss':  round(avg_pl, 6),
            'value_loss':   round(avg_vl, 6),
            'steps':        step + 1,
        })

        if ep_return > best_ret:
            best_ret = ep_return
            torch.save(model.state_dict(), best_path)

        if episode % 50 == 0:
            print(f"[Obst]   Ep {episode:4d} | "
                  f"Return={ep_return:7.2f} | Reached={reached_goal} | "
                  f"BestRet={best_ret:.2f}")

    _save_csv(
        os.path.join(log_dir, 'obstacle_training_log.csv'),
        log_rows,
        ['episode', 'return', 'reached_goal', 'collision',
         'policy_loss', 'value_loss', 'steps']
    )

    model.load_state_dict(torch.load(best_path, map_location='cpu'))
    print(f"[Obst]   Training complete. Best return={best_ret:.2f}. "
          f"Weights saved to {best_path}")
    return model
