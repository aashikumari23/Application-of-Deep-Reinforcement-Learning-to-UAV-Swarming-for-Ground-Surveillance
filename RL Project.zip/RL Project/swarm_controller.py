"""
swarm_controller.py
-------------------
Centralised rule-based Swarm Controller (SC).

Responsibilities (paper Section 3.2 & 3.3):
  1. Maintain a fused operational picture (UAV states + detected targets).
  2. Generate search tasks covering the entire operation area.
  3. Assign tracking tasks when UAVs detect new targets.
  4. Reassign tasks on target loss or UAV availability changes.

This is deterministic logic — NOT trained with RL (the paper states the SC
will be rule-based in the proof-of-concept, with RL reserved for UAV agents).
"""

import math
from typing import List, Optional, Dict, Tuple
from dataclasses import dataclass, field

from environment import (
    SwarmEnvironment, UAVState, TargetState,
    AREA_SIZE, SENSOR_RADIUS
)


@dataclass
class Task:
    task_id:   int
    task_type: str              # 'search' | 'tracking'
    search_area: Optional[Tuple[float, float, float, float]] = None
    target_id:   Optional[int] = None
    assigned_uav: Optional[int] = None
    status: str = 'pending'     # 'pending' | 'active' | 'done' | 'failed'


class SwarmController:
    """
    Implements the mission-planning layer.

    Tracks all known targets, maintains task assignments,
    and rebalances UAV roles every `replan_interval` steps.
    """

    def __init__(self, env: SwarmEnvironment, replan_interval: int = 20):
        self.env              = env
        self.replan_interval  = replan_interval
        self._task_id_counter = 0
        self.tasks:    Dict[int, Task]     = {}
        self.known_targets: Dict[int, TargetState] = {}
        self._step = 0

        # Initial task assignment
        self._initialise_search_tasks()

    # ── initialisation ────────────────────────────────────────────────────

    def _initialise_search_tasks(self):
        """Create one search task per UAV covering the full area."""
        half = self.env.area / 2.0
        n    = self.env.n_uavs
        cols = int(math.ceil(math.sqrt(n)))
        rows = int(math.ceil(n / cols))
        w    = self.env.area / cols
        h    = self.env.area / rows

        for i, uav in enumerate(self.env.uavs):
            c  = i % cols
            r  = i // cols
            sa = (-half + c * w, -half + r * h,
                  -half + (c + 1) * w, -half + (r + 1) * h)
            t  = self._new_task('search', search_area=sa)
            t.assigned_uav = uav.uid
            t.status       = 'active'
            uav.task        = 'search'
            uav.search_area = sa

    # ── main update ───────────────────────────────────────────────────────

    def update(self) -> List[Dict]:
        """
        Called once per simulation step.
        Returns a list of task-assignment events for logging.
        """
        events = []
        self._step += 1

        # 1. Collect sensor reports from all UAVs
        for uav in self.env.uavs:
            for tgt in self.env.targets_in_sensor(uav):
                if tgt.tid not in self.known_targets:
                    self.known_targets[tgt.tid] = tgt
                    ev = self._on_new_target(tgt, uav)
                    if ev:
                        events.append(ev)

        # 2. Periodic replan
        if self._step % self.replan_interval == 0:
            events += self._replan()

        return events

    # ── target discovery ──────────────────────────────────────────────────

    def _on_new_target(self, tgt: TargetState,
                       discovering_uav: UAVState) -> Optional[Dict]:
        """Assign a tracking task to the nearest free UAV."""
        free_uavs = [u for u in self.env.uavs
                     if u.task == 'search' and u.uid != discovering_uav.uid]
        if not free_uavs:
            # Reassign discovering UAV itself
            free_uavs = [discovering_uav]

        # Nearest free UAV to the target
        best = min(free_uavs,
                   key=lambda u: math.hypot(u.x - tgt.x, u.y - tgt.y))

        # Revoke any search task for this UAV
        for task in self.tasks.values():
            if task.assigned_uav == best.uid and task.task_type == 'search':
                task.status = 'done'

        t = self._new_task('tracking', target_id=tgt.tid)
        t.assigned_uav = best.uid
        t.status       = 'active'

        best.task      = 'tracking'
        best.target_id = tgt.tid
        tgt.assigned_uav = best.uid
        tgt.detected   = True

        # Re-distribute search areas among remaining search UAVs
        self._redistribute_search()

        return {
            'event': 'task_assigned',
            'task_type': 'tracking',
            'uav_id': best.uid,
            'target_id': tgt.tid,
        }

    # ── replanning ────────────────────────────────────────────────────────

    def _replan(self) -> List[Dict]:
        events = []
        # Check tracking UAVs that have lost their target
        for uav in self.env.uavs:
            if uav.task != 'tracking':
                continue
            if uav.target_id is None:
                continue
            tgt = self.env.targets[uav.target_id]
            if not tgt.active:
                # Target left the area → revert to search
                uav.task      = 'search'
                uav.target_id = None
                self._redistribute_search()
                events.append({'event': 'revert_search', 'uav_id': uav.uid})
        return events

    def _redistribute_search(self):
        """Re-divide area among UAVs currently assigned to search."""
        searchers = [u for u in self.env.uavs if u.task == 'search']
        if not searchers:
            return
        half = self.env.area / 2.0
        n    = len(searchers)
        cols = int(math.ceil(math.sqrt(n)))
        rows = int(math.ceil(n / cols))
        w    = self.env.area / cols
        h    = self.env.area / rows
        for i, uav in enumerate(searchers):
            c  = i % cols
            r  = i // cols
            sa = (-half + c * w, -half + r * h,
                  -half + (c + 1) * w, -half + (r + 1) * h)
            uav.search_area = sa
            # Update active search task
            for task in self.tasks.values():
                if (task.assigned_uav == uav.uid
                        and task.task_type == 'search'
                        and task.status == 'active'):
                    task.search_area = sa

    # ── helpers ───────────────────────────────────────────────────────────

    def _new_task(self, task_type: str, **kwargs) -> Task:
        tid  = self._task_id_counter
        task = Task(task_id=tid, task_type=task_type, **kwargs)
        self.tasks[tid] = task
        self._task_id_counter += 1
        return task

    # ── status summary ────────────────────────────────────────────────────

    def status_summary(self) -> Dict:
        n_search   = sum(1 for u in self.env.uavs if u.task == 'search')
        n_tracking = sum(1 for u in self.env.uavs if u.task == 'tracking')
        n_detected = len(self.known_targets)
        return {
            'step':        self._step,
            'n_search':    n_search,
            'n_tracking':  n_tracking,
            'n_detected':  n_detected,
        }
