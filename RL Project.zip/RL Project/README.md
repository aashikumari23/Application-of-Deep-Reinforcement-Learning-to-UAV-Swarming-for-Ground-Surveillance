# UAV Swarm Ground Surveillance — LSTM + PPO

Implementation of the hybrid AI swarm system described in:

> Arranz et al., "Application of Deep Reinforcement Learning to UAV Swarming
> for Ground Surveillance", *Sensors* 2023, 23, 8766.

---

## Architecture

```
main.py
│
├── training.py          ← PPO training loops for 3 sub-agents
│   ├── train_search_agent()
│   ├── train_tracking_agent()
│   └── train_obstacle_agent()
│
├── execution.py         ← Full mission run with trained agents
│
├── environment.py       ← 2D physics, sensors, obstacles, targets
├── models.py            ← LSTM ActorCritic neural network
├── trainer.py           ← PPO rollout buffer + update logic
├── rewards.py           ← Reward functions (Tables 2, 3, 4 in paper)
├── swarm_controller.py  ← Centralised rule-based SC (mission planning)
└── logger.py            ← Structured CSV output
```

---

## Three Sub-Agents (Paper Section 3.3)

| Sub-Agent     | Activated when                          | Obs dim | Paper ref   |
|---------------|-----------------------------------------|---------|-------------|
| **Search**    | Task == `search` and no proximal hazard | 12      | §3.3.1      |
| **Tracking**  | Task == `tracking` and no proximal hazard | 12    | §3.3.2      |
| **Obstacle**  | Proximity sensor fires                  | 12      | §3.3.3      |

All three share the same LSTM actor-critic architecture
(`models.LSTMActorCritic`):

```
obs → FC(128, Tanh) → LSTM(128) → Actor head → (δheading, thrust)
                                 → Critic head → V(s)
```

---

## Swarm Controller (Mission Planning Layer)

The centralised **SwarmController** (`swarm_controller.py`) is rule-based:

1. Starts with one search task per UAV, covering equal rectangular strips.
2. When a UAV detects a new target → assigns a **tracking task** to the
   nearest free UAV.
3. Re-distributes remaining search areas among non-tracking UAVs.
4. Every `replan_interval` steps, checks for lost targets and reverts
   tracking UAVs to search.

---

## Quick Start

### Install dependencies

```bash
pip install -r requirements.txt
```

### Train + Execute (default settings)

```bash
python main.py
```

### Faster smoke-test

```bash
python main.py --episodes 50 --steps 300 --exec-steps 200
```

### Skip training (use saved checkpoints)

```bash
python main.py --skip-training
```

### Custom configuration

```bash
python main.py \
    --episodes 500      \   # PPO training episodes per sub-agent
    --steps    800      \   # Max steps per training episode
    --exec-steps 750    \   # Execution steps
    --uavs     8        \   # UAVs in execution
    --targets  5        \   # Ground targets
    --seed     42       \   # RNG seed
    --checkpoint-dir checkpoints \
    --out-dir simulation_data    \
    --log-dir logs
```

---

## Output Files

### Training logs (`logs/`)

| File                          | Columns                                                      |
|-------------------------------|--------------------------------------------------------------|
| `search_training_log.csv`     | episode, return, coverage_pct, policy_loss, value_loss, steps |
| `tracking_training_log.csv`   | episode, return, consec_detect, policy_loss, value_loss, steps |
| `obstacle_training_log.csv`   | episode, return, reached_goal, collision, policy_loss, value_loss, steps |

### Simulation data (`simulation_data/`)

| File                    | Rows per step | Key columns                                                  |
|-------------------------|---------------|--------------------------------------------------------------|
| `uav_states.csv`        | 1 per UAV     | step, uav_id, x, y, heading_deg, speed, task, active_subagent, target_id, reward, collision |
| `target_states.csv`     | 1 per target  | step, target_id, x, y, vx, vy, detected, assigned_uav        |
| `events.csv`            | 0–N per step  | step, event_type, uav_id, target_id, task_type, detail        |
| `metrics.csv`           | 1             | step, n_search_uavs, n_tracking_uavs, n_detected_targets, pct_detected, n_collisions_this_step, mean_uav_speed |
| `execution_summary.csv` | 1             | step, n_detected, n_total, pct_detected                       |

These files contain everything needed to reconstruct and visualise the
entire mission: UAV trajectories, target movements, task assignments,
sensor detections, and collision events.

---

## Evaluation Metrics (Paper Section 4.1)

The CSVs support computing all five metrics from the paper:

| Metric                  | How to compute from CSVs                              |
|-------------------------|-------------------------------------------------------|
| **Revisit period**      | Group `uav_states.csv` by cell, compute gap durations |
| **Search time**         | First step where `pct_detected == 100` in `metrics.csv` |
| **% detected targets**  | `pct_detected` column in `metrics.csv`                |
| **Tracking continuity** | Fraction of steps `detected==1` per target in `target_states.csv` |
| **Target acquisition time** | First `step` where `detected==1` per `target_id` in `target_states.csv` |

---

## Environment Parameters

| Parameter       | Value   | Description                      |
|-----------------|---------|----------------------------------|
| `AREA_SIZE`     | 6000 m  | Square operation area side       |
| `UAV_MIN_SPEED` | 35 m/s  | Fixed-wing minimum speed         |
| `UAV_MAX_SPEED` | 120 m/s | Fixed-wing maximum speed         |
| `SENSOR_RADIUS` | 400 m   | UAV sensor coverage radius       |
| `PROXIMITY_RADIUS` | 150 m | Obstacle-avoidance trigger range |
| `TARGET_SPEED`  | 20 m/s  | Ground target speed              |
| `DT`            | 1.0 s   | Simulation timestep              |
| `NUM_OBSTACLES` | 12      | Static building obstacles        |
