"""
logger.py
---------
Structured CSV logger for the swarm execution run.

Records every simulation step for later visualisation:
  - UAV states (position, heading, speed, task, sub-agent, UAV type)
  - Target states (position, velocity, detected, assigned UAV)
  - Obstacle states (position, velocity, mobile flag) — NEW
  - Task events (assignment, completion, failure)
  - Swarm-level metrics (coverage, n_detected, etc.)
  - Sub-agent activation and rewards

Changes from previous version
------------------------------
* UAV_FIELDS gains 'uav_type' column so the type of each UAV is visible
  in every row of uav_states.csv.
* A new OBSTACLE_FIELDS / obstacle_states.csv records every obstacle's
  position and velocity at every step, enabling visualisation of moving
  obstacles.  'mobile' flag (0/1) distinguishes static from moving ones.
"""

import csv
import os
from typing import Optional


# ── column definitions ────────────────────────────────────────────────────

UAV_FIELDS = [
    'step', 'uav_id', 'uav_type',                          # NEW: uav_type
    'x', 'y', 'heading_deg', 'speed',
    'task', 'active_subagent', 'target_id',
    'search_area_x0', 'search_area_y0', 'search_area_x1', 'search_area_y1',
    'reward', 'collision',
]

TARGET_FIELDS = [
    'step', 'target_id', 'x', 'y', 'vx', 'vy',
    'detected', 'assigned_uav',
]

OBSTACLE_FIELDS = [                                        # NEW
    'step', 'obstacle_id', 'x', 'y', 'vx', 'vy',
    'size', 'mobile',
]

EVENT_FIELDS = [
    'step', 'event_type', 'uav_id', 'target_id',
    'task_type', 'detail',
]

METRIC_FIELDS = [
    'step',
    'n_search_uavs', 'n_tracking_uavs',
    'n_detected_targets', 'n_total_targets',
    'pct_detected',
    'n_collisions_this_step',
    'mean_uav_speed',
]


class SwarmLogger:
    """
    Opens five CSV files and provides record_*() methods called
    at each simulation step.
    """

    def __init__(self, out_dir: str = 'simulation_data'):
        os.makedirs(out_dir, exist_ok=True)

        self._uav_f  = open(os.path.join(out_dir, 'uav_states.csv'),      'w', newline='')
        self._tgt_f  = open(os.path.join(out_dir, 'target_states.csv'),   'w', newline='')
        self._obs_f  = open(os.path.join(out_dir, 'obstacle_states.csv'), 'w', newline='')  # NEW
        self._evt_f  = open(os.path.join(out_dir, 'events.csv'),          'w', newline='')
        self._met_f  = open(os.path.join(out_dir, 'metrics.csv'),         'w', newline='')

        self._uav_w  = csv.DictWriter(self._uav_f,  fieldnames=UAV_FIELDS)
        self._tgt_w  = csv.DictWriter(self._tgt_f,  fieldnames=TARGET_FIELDS)
        self._obs_w  = csv.DictWriter(self._obs_f,  fieldnames=OBSTACLE_FIELDS)  # NEW
        self._evt_w  = csv.DictWriter(self._evt_f,  fieldnames=EVENT_FIELDS)
        self._met_w  = csv.DictWriter(self._met_f,  fieldnames=METRIC_FIELDS)

        for w in (self._uav_w, self._tgt_w, self._obs_w, self._evt_w, self._met_w):
            w.writeheader()

        self._out_dir = out_dir

    # ── record methods ────────────────────────────────────────────────────

    def record_uav(self, step: int, uav, reward: float, collision: bool):
        import math
        sa = uav.search_area or (None, None, None, None)
        self._uav_w.writerow({
            'step':            step,
            'uav_id':          uav.uid,
            'uav_type':        uav.uav_type,               # NEW
            'x':               round(uav.x, 2),
            'y':               round(uav.y, 2),
            'heading_deg':     round(math.degrees(uav.heading) % 360, 2),
            'speed':           round(uav.speed, 2),
            'task':            uav.task,
            'active_subagent': uav.active_subagent,
            'target_id':       uav.target_id if uav.target_id is not None else '',
            'search_area_x0':  round(sa[0], 1) if sa[0] is not None else '',
            'search_area_y0':  round(sa[1], 1) if sa[1] is not None else '',
            'search_area_x1':  round(sa[2], 1) if sa[2] is not None else '',
            'search_area_y1':  round(sa[3], 1) if sa[3] is not None else '',
            'reward':          round(reward, 4),
            'collision':       int(collision),
        })

    def record_target(self, step: int, target):
        self._tgt_w.writerow({
            'step':         step,
            'target_id':    target.tid,
            'x':            round(target.x, 2),
            'y':            round(target.y, 2),
            'vx':           round(target.vx, 3),
            'vy':           round(target.vy, 3),
            'detected':     int(target.detected),
            'assigned_uav': target.assigned_uav if target.assigned_uav is not None else '',
        })

    def record_obstacles(self, step: int, obstacles):
        """
        Write one row per obstacle.
        'mobile' is 1 if vx or vy is non-zero, 0 otherwise.
        Called once per step from execution.py after step_obstacles().
        """
        for oid, obs in enumerate(obstacles):
            mobile = int(obs.vx != 0.0 or obs.vy != 0.0)
            self._obs_w.writerow({
                'step':        step,
                'obstacle_id': oid,
                'x':           round(obs.x, 2),
                'y':           round(obs.y, 2),
                'vx':          round(obs.vx, 4),
                'vy':          round(obs.vy, 4),
                'size':        obs.size,
                'mobile':      mobile,
            })

    def record_event(self, step: int, event_type: str,
                     uav_id: Optional[int] = None,
                     target_id: Optional[int] = None,
                     task_type: str = '',
                     detail: str = ''):
        self._evt_w.writerow({
            'step':       step,
            'event_type': event_type,
            'uav_id':     uav_id if uav_id is not None else '',
            'target_id':  target_id if target_id is not None else '',
            'task_type':  task_type,
            'detail':     detail,
        })

    def record_metrics(self, step: int, env, n_collisions: int):
        n_search   = sum(1 for u in env.uavs if u.task == 'search')
        n_tracking = sum(1 for u in env.uavs if u.task == 'tracking')
        n_detected = sum(1 for t in env.targets if t.detected)
        n_total    = len(env.targets)
        pct        = n_detected / max(n_total, 1) * 100.0
        mean_speed = sum(u.speed for u in env.uavs) / max(len(env.uavs), 1)

        self._met_w.writerow({
            'step':                   step,
            'n_search_uavs':          n_search,
            'n_tracking_uavs':        n_tracking,
            'n_detected_targets':     n_detected,
            'n_total_targets':        n_total,
            'pct_detected':           round(pct, 2),
            'n_collisions_this_step': n_collisions,
            'mean_uav_speed':         round(mean_speed, 2),
        })

    # ── lifecycle ─────────────────────────────────────────────────────────

    def flush(self):
        for f in (self._uav_f, self._tgt_f, self._obs_f, self._evt_f, self._met_f):
            f.flush()

    def close(self):
        for f in (self._uav_f, self._tgt_f, self._obs_f, self._evt_f, self._met_f):
            f.close()
        print(f"[Logger] Data written to '{self._out_dir}/'")
        print(f"         Files: uav_states.csv, target_states.csv, "
              f"obstacle_states.csv, events.csv, metrics.csv")
