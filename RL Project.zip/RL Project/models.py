"""
models.py
---------
LSTM-based actor-critic networks for the three sub-agents:
  SearchAgent, TrackingAgent, ObstacleAvoidanceAgent

Each network outputs:
  - policy logits / continuous action mean (delta_heading, thrust)
  - state-value estimate V(s)

Training uses a simplified PPO update (on-policy, clipped surrogate loss).
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Tuple


# ── observation / action dimensions ─────────────────────────────────────────
SEARCH_OBS_DIM     = 12
TRACKING_OBS_DIM   = 12
OBSTACLE_OBS_DIM   = 12

# Both heading and thrust are continuous in [-1, 1]
ACTION_DIM = 2

HIDDEN_DIM  = 128
LSTM_LAYERS = 1


class LSTMActorCritic(nn.Module):
    """
    Shared LSTM backbone → separate actor and critic heads.
    Input:  (batch, seq_len, obs_dim)  or  (batch, obs_dim) if seq_len=1
    Output: action_mean (batch, 2), value (batch, 1), hidden state
    """

    def __init__(self, obs_dim: int, hidden_dim: int = HIDDEN_DIM):
        super().__init__()
        self.obs_dim    = obs_dim
        self.hidden_dim = hidden_dim

        # Feature extractor
        self.fc_in = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
        )

        # Recurrent core
        self.lstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=hidden_dim,
            num_layers=LSTM_LAYERS,
            batch_first=True,
        )

        # Actor head → mean of Gaussian policy
        self.actor_mean = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, ACTION_DIM),
            nn.Tanh(),   # outputs in (-1, 1)
        )

        # Log-std as learnable parameter (not state-dependent)
        self.log_std = nn.Parameter(torch.zeros(ACTION_DIM) - 0.5)

        # Critic head
        self.critic = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    def init_hidden(self, batch_size: int = 1
                    ) -> Tuple[torch.Tensor, torch.Tensor]:
        h = torch.zeros(LSTM_LAYERS, batch_size, self.hidden_dim)
        c = torch.zeros(LSTM_LAYERS, batch_size, self.hidden_dim)
        return h, c

    def forward(self, obs: torch.Tensor,
                hidden: Tuple[torch.Tensor, torch.Tensor]
                ) -> Tuple[torch.Tensor, torch.Tensor,
                           Tuple[torch.Tensor, torch.Tensor]]:
        """
        obs    : (batch, seq_len, obs_dim)  — seq_len=1 during rollout
        Returns: mean (batch, seq_len, 2), value (batch, seq_len, 1), new_hidden
        """
        batch, seq, _ = obs.shape
        x = self.fc_in(obs.reshape(batch * seq, -1))
        x = x.reshape(batch, seq, -1)
        x, new_hidden = self.lstm(x, hidden)
        mean  = self.actor_mean(x)
        value = self.critic(x)
        return mean, value, new_hidden

    def get_action_and_value(self, obs: torch.Tensor,
                             hidden: Tuple[torch.Tensor, torch.Tensor],
                             action: torch.Tensor = None):
        """
        Used during PPO update.
        Returns: action, log_prob, entropy, value, new_hidden
        """
        mean, value, new_hidden = self.forward(obs, hidden)
        std  = self.log_std.exp().expand_as(mean)
        dist = torch.distributions.Normal(mean, std)
        if action is None:
            action = dist.sample()
        log_prob = dist.log_prob(action).sum(-1, keepdim=True)
        entropy  = dist.entropy().sum(-1, keepdim=True)
        return action, log_prob, entropy, value, new_hidden

    @torch.no_grad()
    def act(self, obs_np: np.ndarray,
            hidden: Tuple[torch.Tensor, torch.Tensor]
            ) -> Tuple[np.ndarray, Tuple[torch.Tensor, torch.Tensor]]:
        """
        Single-step inference (no gradient).
        obs_np: 1D numpy array of shape (obs_dim,)
        Returns: action_np (2,), new_hidden
        """
        obs_t = torch.FloatTensor(obs_np).unsqueeze(0).unsqueeze(0)  # (1,1,D)
        mean, _, new_hidden = self.forward(obs_t, hidden)
        std  = self.log_std.exp().expand_as(mean)
        dist = torch.distributions.Normal(mean, std)
        action = dist.sample().squeeze().numpy()
        return np.clip(action, -1.0, 1.0), new_hidden


# ── convenience constructors ──────────────────────────────────────────────

def make_search_agent()   -> LSTMActorCritic:
    return LSTMActorCritic(SEARCH_OBS_DIM)

def make_tracking_agent() -> LSTMActorCritic:
    return LSTMActorCritic(TRACKING_OBS_DIM)

def make_obstacle_agent() -> LSTMActorCritic:
    return LSTMActorCritic(OBSTACLE_OBS_DIM)
