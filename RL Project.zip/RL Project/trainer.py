"""
trainer.py
----------
PPO (Proximal Policy Optimisation) trainer for LSTM actor-critic sub-agents.

Each trainer holds its own rollout buffer and runs the clipped-surrogate
PPO update after a fixed number of environment steps.

Reference: Schulman et al., "Proximal Policy Optimization Algorithms" (2017)
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass, field
from models import LSTMActorCritic


# ── PPO hyperparameters ───────────────────────────────────────────────────

@dataclass
class PPOConfig:
    lr:              float = 3e-4
    gamma:           float = 0.99
    gae_lambda:      float = 0.95
    clip_epsilon:    float = 0.2
    vf_coef:         float = 0.5
    ent_coef:        float = 0.01
    max_grad_norm:   float = 0.5
    n_epochs:        int   = 4        # PPO update epochs per rollout
    minibatch_size:  int   = 64
    rollout_steps:   int   = 512      # steps collected before each update


# ── rollout buffer ────────────────────────────────────────────────────────

@dataclass
class RolloutBuffer:
    obs:       List[np.ndarray] = field(default_factory=list)
    actions:   List[np.ndarray] = field(default_factory=list)
    log_probs: List[float]      = field(default_factory=list)
    rewards:   List[float]      = field(default_factory=list)
    values:    List[float]      = field(default_factory=list)
    dones:     List[bool]       = field(default_factory=list)
    # LSTM hidden states at the start of each step
    hiddens_h: List[np.ndarray] = field(default_factory=list)
    hiddens_c: List[np.ndarray] = field(default_factory=list)

    def clear(self):
        for lst in (self.obs, self.actions, self.log_probs,
                    self.rewards, self.values, self.dones,
                    self.hiddens_h, self.hiddens_c):
            lst.clear()

    def __len__(self):
        return len(self.rewards)


# ── trainer ───────────────────────────────────────────────────────────────

class PPOTrainer:
    """
    Trains one LSTMActorCritic model with PPO.
    Accumulates experience from the outside via `record_step()`,
    then calls `update()` when the buffer is full.
    """

    def __init__(self, model: LSTMActorCritic,
                 config: PPOConfig = None,
                 device: str = 'cpu'):
        self.model   = model.to(device)
        self.cfg     = config or PPOConfig()
        self.device  = device
        self.buffer  = RolloutBuffer()
        self.opt     = optim.Adam(model.parameters(), lr=self.cfg.lr)
        self.total_steps = 0
        self.update_count = 0
        self._last_loss: Dict[str, float] = {}

        # Running hidden state for data collection
        self._hidden = model.init_hidden(1)

    # ── data collection helpers ───────────────────────────────────────────

    def reset_hidden(self):
        self._hidden = self.model.init_hidden(1)

    def select_action(self, obs: np.ndarray
                      ) -> Tuple[np.ndarray, float, float]:
        """
        Returns action, log_prob (scalar), value (scalar).
        Updates internal hidden state.
        """
        obs_t = torch.FloatTensor(obs).unsqueeze(0).unsqueeze(0)
        h = (self._hidden[0].to(self.device),
             self._hidden[1].to(self.device))

        with torch.no_grad():
            action_t, log_prob_t, _, value_t, new_h = \
                self.model.get_action_and_value(obs_t, h)

        self._hidden = (new_h[0].cpu(), new_h[1].cpu())
        action   = action_t.squeeze().cpu().numpy()
        log_prob = log_prob_t.squeeze().item()
        value    = value_t.squeeze().item()
        return np.clip(action, -1.0, 1.0), log_prob, value

    def record_step(self, obs: np.ndarray, action: np.ndarray,
                    log_prob: float, reward: float,
                    value: float, done: bool):
        buf = self.buffer
        buf.obs.append(obs.copy())
        buf.actions.append(action.copy())
        buf.log_probs.append(log_prob)
        buf.rewards.append(reward)
        buf.values.append(value)
        buf.dones.append(done)
        buf.hiddens_h.append(self._hidden[0].numpy().copy())
        buf.hiddens_c.append(self._hidden[1].numpy().copy())
        self.total_steps += 1

    def should_update(self) -> bool:
        return len(self.buffer) >= self.cfg.rollout_steps

    # ── PPO update ────────────────────────────────────────────────────────

    def update(self, last_value: float = 0.0) -> Dict[str, float]:
        buf = self.buffer
        n   = len(buf)
        cfg = self.cfg

        # ── GAE advantage computation ────────────────────────────────────
        advantages = np.zeros(n, dtype=np.float32)
        returns    = np.zeros(n, dtype=np.float32)
        gae = 0.0
        for t in reversed(range(n)):
            next_val  = last_value if t == n - 1 else buf.values[t + 1]
            not_done  = 0.0 if buf.dones[t] else 1.0
            delta     = (buf.rewards[t]
                         + cfg.gamma * next_val * not_done
                         - buf.values[t])
            gae       = delta + cfg.gamma * cfg.gae_lambda * not_done * gae
            advantages[t] = gae
            returns[t]    = gae + buf.values[t]

        # Normalise advantages
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # ── Convert buffer to tensors ────────────────────────────────────
        obs_t     = torch.FloatTensor(np.array(buf.obs)).to(self.device)
        act_t     = torch.FloatTensor(np.array(buf.actions)).to(self.device)
        old_lp_t  = torch.FloatTensor(np.array(buf.log_probs)).to(self.device)
        adv_t     = torch.FloatTensor(advantages).to(self.device)
        ret_t     = torch.FloatTensor(returns).to(self.device)

        total_pl = total_vl = total_el = 0.0
        n_updates = 0

        for _ in range(cfg.n_epochs):
            indices = np.random.permutation(n)
            for start in range(0, n, cfg.minibatch_size):
                idx = indices[start: start + cfg.minibatch_size]
                if len(idx) < 4:
                    continue

                mb_obs  = obs_t[idx].unsqueeze(1)   # (B, 1, D)
                mb_act  = act_t[idx].unsqueeze(1)   # (B, 1, 2)
                mb_adv  = adv_t[idx]
                mb_ret  = ret_t[idx]
                mb_olp  = old_lp_t[idx]

                # Re-init hidden for each mini-batch (truncated BPTT)
                h = self.model.init_hidden(len(idx))
                h = (h[0].to(self.device), h[1].to(self.device))

                _, lp, ent, val, _ = \
                    self.model.get_action_and_value(mb_obs, h, mb_act)

                lp  = lp.squeeze()
                val = val.squeeze()
                ent = ent.squeeze()

                ratio   = (lp - mb_olp).exp()
                pg_loss = torch.min(
                    ratio * mb_adv,
                    torch.clamp(ratio, 1 - cfg.clip_epsilon,
                                       1 + cfg.clip_epsilon) * mb_adv
                ).mean()

                vf_loss  = nn.functional.mse_loss(val, mb_ret)
                ent_loss = ent.mean()

                loss = (-pg_loss
                        + cfg.vf_coef  * vf_loss
                        - cfg.ent_coef * ent_loss)

                self.opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(),
                                         cfg.max_grad_norm)
                self.opt.step()

                total_pl += pg_loss.item()
                total_vl += vf_loss.item()
                total_el += ent_loss.item()
                n_updates += 1

        self.buffer.clear()
        self.update_count += 1
        self._last_loss = {
            'policy_loss': total_pl / max(n_updates, 1),
            'value_loss':  total_vl / max(n_updates, 1),
            'entropy':     total_el / max(n_updates, 1),
        }
        return self._last_loss

    @property
    def last_loss(self):
        return self._last_loss
