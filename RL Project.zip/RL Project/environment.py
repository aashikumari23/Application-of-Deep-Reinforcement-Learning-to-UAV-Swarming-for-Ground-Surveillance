"""
environment.py
--------------
2D simulated environment for UAV swarm surveillance.
Handles targets, obstacles, UAV physics, sensor coverage, and collision detection.

New in this version
───────────────────
* UAV types  — 'default' | 'searcher' | 'trailer'
  Each type has its own speed limits, sensor radius, and proximity threshold.
  A UAVConfig dataclass carries those values; UAVState stores its type name
  and resolved config so every other module can read them.

* Moving obstacles — each Obstacle now has an optional velocity (vx, vy).
  step_obstacles() is called once per sim step and bounces them off walls.
  mobility_prob  (0–1) controls the fraction of obstacles that are mobile.
  obstacle_speed (m/s) controls how fast mobile obstacles drift.
  All obstacle positions are captured by the logger every step via the
  public `obstacles` list (no separate API needed).
"""

import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict
import math


# ── world-level constants (unchanged) ──────────────────────────────────────
AREA_SIZE         = 6000.0   # metres, square side
DT                = 1.0      # seconds per simulation step
TARGET_SPEED      = 20.0     # m/s
OBSTACLE_SIZE     = 120.0    # half-side of square building footprint
NUM_OBSTACLES     = 12


# ── per-type UAV constants ─────────────────────────────────────────────────
# These are the tuneable defaults that UAVConfig objects start from.
# Nothing else in the code hard-codes UAV speed or sensor values any more.

UAV_MIN_SPEED     = 35.0     # m/s  — kept as a global floor (used in training)
UAV_MAX_SPEED     = 120.0    # m/s  — kept as a global ceiling
UAV_DEFAULT_SPEED = 70.0     # m/s  — default type cruising speed
UAV_TURN_RATE     = 0.15     # rad/step — shared across types
SENSOR_RADIUS     = 400.0    # metres  — default type sensor radius
PROXIMITY_RADIUS  = 150.0    # metres  — default type obstacle-trigger radius


# ── UAV type catalogue ─────────────────────────────────────────────────────

@dataclass
class UAVConfig:
    """
    Per-type physical and sensor parameters.
    Stored on each UAVState instance so every module can query them.

    Fields
    ------
    type_name        : human-readable label logged to CSV
    min_speed        : m/s  lower speed clamp
    max_speed        : m/s  upper speed clamp
    default_speed    : m/s  initial / cruise speed
    sensor_radius    : m    target-detection radius
    proximity_radius : m    obstacle-avoidance trigger radius
                           (smaller => less cautious / more careless)
    """
    type_name:        str
    min_speed:        float
    max_speed:        float
    default_speed:    float
    sensor_radius:    float
    proximity_radius: float


# Pre-built catalogue — referenced in main.py and SwarmEnvironment
UAV_TYPE_CONFIGS: Dict[str, UAVConfig] = {
    'default': UAVConfig(
        type_name        = 'default',
        min_speed        = 35.0,
        max_speed        = 120.0,
        default_speed    = 70.0,
        sensor_radius    = 400.0,
        proximity_radius = 150.0,
    ),
    'searcher': UAVConfig(
        # Slower but wider sensor; very cautious obstacle avoidance
        type_name        = 'searcher',
        min_speed        = 25.0,
        max_speed        = 80.0,
        default_speed    = 50.0,
        sensor_radius    = 560.0,   # +40 % search radius
        proximity_radius = 220.0,   # +47 % trigger zone => more cautious
    ),
    'trailer': UAVConfig(
        # Fast but narrow sensor; careless about obstacles
        type_name        = 'trailer',
        min_speed        = 55.0,
        max_speed        = 150.0,
        default_speed    = 100.0,
        sensor_radius    = 280.0,   # -30 % search radius
        proximity_radius = 80.0,    # -47 % trigger zone => more careless
    ),
}


# ── dataclasses ───────────────────────────────────────────────────────────

@dataclass
class UAVState:
    uid:     int
    x:       float
    y:       float
    heading: float          # radians
    speed:   float
    task:    str            # 'search' | 'tracking' | 'idle'
    cfg:     UAVConfig      # type-specific parameters
    target_id:       Optional[int]                           = None
    search_area:     Optional[Tuple[float,float,float,float]] = None
    active_subagent: str = 'search'   # 'search' | 'tracking' | 'obstacle'

    @property
    def uav_type(self) -> str:
        """Convenience accessor for the type name string."""
        return self.cfg.type_name


@dataclass
class TargetState:
    tid: int
    x:   float
    y:   float
    vx:  float
    vy:  float
    active:       bool          = True
    detected:     bool          = False
    assigned_uav: Optional[int] = None


@dataclass
class Obstacle:
    x:    float   # centre x
    y:    float   # centre y
    size: float = OBSTACLE_SIZE
    vx:   float = 0.0   # velocity — zero means static
    vy:   float = 0.0


# ── environment ────────────────────────────────────────────────────────────

class SwarmEnvironment:
    """
    Manages the 2-D world: obstacles, targets, UAVs.

    New constructor parameters (all optional, preserve old behaviour)
    --------------------------
    uav_type_counts         : dict e.g. {'default': 4, 'searcher': 2, 'trailer': 2}
                              If None, falls back to n_uavs all-'default' UAVs.
    obstacle_mobility_prob  : float [0,1] — fraction of obstacles that move
    obstacle_speed          : float (m/s) — speed of mobile obstacles
    """

    def __init__(
        self,
        n_uavs:      int  = 8,
        n_targets:   int  = 5,
        seed:        int  = 42,
        n_obstacles: int  = NUM_OBSTACLES,
        # ── new parameters ──────────────────────────────────────────────
        uav_type_counts:        Optional[Dict[str, int]] = None,
        obstacle_mobility_prob: float = 0.0,
        obstacle_speed:         float = 5.0,
    ):
        self.n_targets   = n_targets
        self.rng         = np.random.default_rng(seed)
        self.n_obstacles = n_obstacles
        self.area        = AREA_SIZE

        # Resolve UAV type list from counts dict or plain n_uavs
        if uav_type_counts is not None:
            self._uav_type_list: List[str] = []
            for type_name, count in uav_type_counts.items():
                if type_name not in UAV_TYPE_CONFIGS:
                    raise ValueError(
                        f"Unknown UAV type '{type_name}'. "
                        f"Valid types: {list(UAV_TYPE_CONFIGS)}"
                    )
                self._uav_type_list.extend([type_name] * count)
        else:
            self._uav_type_list = ['default'] * n_uavs

        self.n_uavs = len(self._uav_type_list)

        # Obstacle motion parameters
        self._mob_prob  = float(np.clip(obstacle_mobility_prob, 0.0, 1.0))
        self._obs_speed = max(0.0, obstacle_speed)

        self.obstacles:  List[Obstacle]    = []
        self.targets:    List[TargetState] = []
        self.uavs:       List[UAVState]    = []
        self.step_count: int               = 0

        self._build_world()

    # ── world construction ─────────────────────────────────────────────────

    def _build_world(self):
        half = self.area / 2.0

        # ── Obstacles ────────────────────────────────────────────────────
        self.obstacles = []
        placed, attempts = 0, 0
        while placed < self.n_obstacles and attempts < 1000:
            ox = self.rng.uniform(-half * 0.9, half * 0.9)
            oy = self.rng.uniform(-half * 0.9, half * 0.9)
            if abs(ox) > 200 or abs(oy) > 200:
                if self.rng.random() < self._mob_prob:
                    angle = self.rng.uniform(0, 2 * math.pi)
                    vx = self._obs_speed * math.cos(angle)
                    vy = self._obs_speed * math.sin(angle)
                else:
                    vx = vy = 0.0
                self.obstacles.append(Obstacle(ox, oy, vx=vx, vy=vy))
                placed += 1
            attempts += 1

        # ── Targets ──────────────────────────────────────────────────────
        self.targets = []
        for i in range(self.n_targets):
            angle = self.rng.uniform(0, 2 * math.pi)
            tx = self.rng.uniform(-half * 0.8, half * 0.8)
            ty = self.rng.uniform(-half * 0.8, half * 0.8)
            self.targets.append(TargetState(
                tid=i, x=tx, y=ty,
                vx=TARGET_SPEED * math.cos(angle),
                vy=TARGET_SPEED * math.sin(angle),
            ))

        # ── UAVs ─────────────────────────────────────────────────────────
        self.uavs = []
        for i, type_name in enumerate(self._uav_type_list):
            cfg   = UAV_TYPE_CONFIGS[type_name]
            angle = 2 * math.pi * i / self.n_uavs
            ux    = 200 * math.cos(angle)
            uy    = 200 * math.sin(angle)
            self.uavs.append(UAVState(
                uid     = i,
                x       = ux,
                y       = uy,
                heading = angle,
                speed   = cfg.default_speed,
                task    = 'search',
                cfg     = cfg,
            ))

        self.step_count = 0
        self._assign_initial_search_areas()

    def _assign_initial_search_areas(self):
        """Divide area into equal strips, one per UAV."""
        half = self.area / 2.0
        n    = self.n_uavs
        cols = int(math.ceil(math.sqrt(n)))
        rows = int(math.ceil(n / cols))
        w    = self.area / cols
        h    = self.area / rows
        for i, uav in enumerate(self.uavs):
            c = i % cols
            r = i // cols
            uav.search_area = (
                -half + c * w,
                -half + r * h,
                -half + (c + 1) * w,
                -half + (r + 1) * h,
            )

    def reset(self, seed: Optional[int] = None):
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self._build_world()

    # ── physics ────────────────────────────────────────────────────────────

    def apply_uav_action(self, uav: UAVState,
                         delta_heading: float, thrust: float):
        """
        delta_heading : clamped turn (radians)
        thrust        : [-1, +1] -> speed change
        Uses per-type speed limits from uav.cfg.
        """
        delta_heading = float(np.clip(delta_heading,
                                      -UAV_TURN_RATE, UAV_TURN_RATE))
        uav.heading = (uav.heading + delta_heading) % (2 * math.pi)

        accel     = float(np.clip(thrust, -1.0, 1.0)) * 10.0
        uav.speed = float(np.clip(
            uav.speed + accel * DT,
            uav.cfg.min_speed,
            uav.cfg.max_speed,
        ))

        uav.x += uav.speed * math.cos(uav.heading) * DT
        uav.y += uav.speed * math.sin(uav.heading) * DT

        # Bounce off area boundary
        half = self.area / 2.0
        if uav.x < -half:
            uav.x = -half; uav.heading = math.pi - uav.heading
        elif uav.x > half:
            uav.x =  half; uav.heading = math.pi - uav.heading
        if uav.y < -half:
            uav.y = -half; uav.heading = -uav.heading
        elif uav.y > half:
            uav.y =  half; uav.heading = -uav.heading

    def step_targets(self):
        """Move ground targets; bounce off walls."""
        half = self.area / 2.0
        for t in self.targets:
            if not t.active:
                continue
            t.x += t.vx * DT
            t.y += t.vy * DT
            if t.x < -half or t.x > half:
                t.vx = -t.vx; t.x = float(np.clip(t.x, -half, half))
            if t.y < -half or t.y > half:
                t.vy = -t.vy; t.y = float(np.clip(t.y, -half, half))
            spd = math.hypot(t.vx, t.vy)
            if spd > 0:
                t.vx = t.vx / spd * TARGET_SPEED
                t.vy = t.vy / spd * TARGET_SPEED

    def step_obstacles(self):
        """
        Move mobile obstacles (vx/vy != 0) and bounce them off walls.
        Static obstacles (vx=vy=0) are untouched.
        Called once per simulation step from execution.py.
        """
        half = self.area / 2.0
        for obs in self.obstacles:
            if obs.vx == 0.0 and obs.vy == 0.0:
                continue
            obs.x += obs.vx * DT
            obs.y += obs.vy * DT
            margin = obs.size
            if obs.x < -half + margin:
                obs.x = -half + margin; obs.vx = abs(obs.vx)
            elif obs.x > half - margin:
                obs.x =  half - margin; obs.vx = -abs(obs.vx)
            if obs.y < -half + margin:
                obs.y = -half + margin; obs.vy = abs(obs.vy)
            elif obs.y > half - margin:
                obs.y =  half - margin; obs.vy = -abs(obs.vy)

    # ── sensor queries — use per-UAV config radii ──────────────────────────

    def targets_in_sensor(self, uav: UAVState) -> List[TargetState]:
        """Return targets within this UAV's sensor radius (LOS check included)."""
        r_sq = uav.cfg.sensor_radius ** 2
        visible = []
        for t in self.targets:
            if not t.active:
                continue
            if (t.x - uav.x) ** 2 + (t.y - uav.y) ** 2 <= r_sq:
                if not self._line_blocked(uav.x, uav.y, t.x, t.y):
                    visible.append(t)
        return visible

    def _line_blocked(self, x0, y0, x1, y1) -> bool:
        """AABB line-segment intersection for obstacle occlusion."""
        for obs in self.obstacles:
            if self._segment_aabb(x0, y0, x1, y1,
                                  obs.x - obs.size, obs.y - obs.size,
                                  obs.x + obs.size, obs.y + obs.size):
                return True
        return False

    @staticmethod
    def _segment_aabb(x0, y0, x1, y1, ax, ay, bx, by) -> bool:
        """Cohen-Sutherland parametric clip."""
        dx, dy = x1 - x0, y1 - y0
        p = [-dx, dx, -dy, dy]
        q = [x0 - ax, bx - x0, y0 - ay, by - y0]
        t0, t1 = 0.0, 1.0
        for pi, qi in zip(p, q):
            if pi == 0:
                if qi < 0:
                    return False
            elif pi < 0:
                t0 = max(t0, qi / pi)
            else:
                t1 = min(t1, qi / pi)
        return t0 <= t1

    def obstacles_in_proximity(self, uav: UAVState) -> List[Tuple[float, float]]:
        """
        Return (dx, dy) vectors to hazards within this UAV's proximity_radius.
        Uses uav.cfg.proximity_radius so 'trailer' UAVs trigger less often.
        """
        prox_r = uav.cfg.proximity_radius
        near   = []
        for obs in self.obstacles:
            dx, dy = obs.x - uav.x, obs.y - uav.y
            if math.hypot(dx, dy) < prox_r + obs.size:
                near.append((dx, dy))
        for other in self.uavs:
            if other.uid == uav.uid:
                continue
            dx, dy = other.x - uav.x, other.y - uav.y
            if math.hypot(dx, dy) < prox_r:
                near.append((dx, dy))
        return near

    def collision_occurred(self, uav: UAVState) -> bool:
        for obs in self.obstacles:
            if math.hypot(uav.x - obs.x, uav.y - obs.y) < obs.size:
                return True
        for other in self.uavs:
            if other.uid == uav.uid:
                continue
            if math.hypot(uav.x - other.x, uav.y - other.y) < 30.0:
                return True
        return False

    # ── observation builders — use per-UAV config radii ───────────────────

    def get_search_obs(self, uav: UAVState) -> np.ndarray:
        """12-element search observation (normalised)."""
        half = self.area / 2.0
        sa   = uav.search_area if uav.search_area else (-half, -half, half, half)
        cx   = (sa[0] + sa[2]) / 2.0
        cy   = (sa[1] + sa[3]) / 2.0
        vx   = uav.speed * math.cos(uav.heading)
        vy   = uav.speed * math.sin(uav.heading)
        return np.array([
            uav.x / half,
            uav.y / half,
            vx / uav.cfg.max_speed,
            vy / uav.cfg.max_speed,
            0.0, 0.0,
            self.area / self.area,
            self.area / self.area,
            (cx - uav.x) / self.area,
            (cy - uav.y) / self.area,
            (sa[2] - sa[0]) / self.area,
            (sa[3] - sa[1]) / self.area,
        ], dtype=np.float32)

    def get_tracking_obs(self, uav: UAVState,
                         target: Optional[TargetState]) -> np.ndarray:
        """12-element tracking observation (normalised)."""
        half = self.area / 2.0
        vx   = uav.speed * math.cos(uav.heading)
        vy   = uav.speed * math.sin(uav.heading)
        if target is not None:
            tdx = (target.x - uav.x) / self.area
            tdy = (target.y - uav.y) / self.area
            tvx = target.vx / uav.cfg.max_speed
            tvy = target.vy / uav.cfg.max_speed
            det = 1.0 if target in self.targets_in_sensor(uav) else 0.0
        else:
            tdx = tdy = tvx = tvy = det = 0.0
        return np.array([
            uav.x / half,
            uav.y / half,
            vx / uav.cfg.max_speed,
            vy / uav.cfg.max_speed,
            0.0, 0.0,
            1.0,
            tdx, tdy,
            tvx, tvy,
            det,
        ], dtype=np.float32)

    def get_obstacle_obs(self, uav: UAVState,
                         goal: Tuple[float, float]) -> np.ndarray:
        """12-element obstacle-avoidance observation (normalised)."""
        half = self.area / 2.0
        vx   = uav.speed * math.cos(uav.heading)
        vy   = uav.speed * math.sin(uav.heading)
        prox = self.obstacles_in_proximity(uav)[:3]
        while len(prox) < 3:
            prox.append((0.0, 0.0))
        flat_prox = [v / self.area for pair in prox for v in pair]
        return np.array([
            uav.x / half,
            uav.y / half,
            vx / uav.cfg.max_speed,
            vy / uav.cfg.max_speed,
            (goal[0] - uav.x) / self.area,
            (goal[1] - uav.y) / self.area,
        ] + flat_prox, dtype=np.float32)

    # ── utility ────────────────────────────────────────────────────────────

    def dist(self, x0, y0, x1, y1) -> float:
        return math.hypot(x1 - x0, y1 - y0)

    def heading_to(self, uav: UAVState, tx: float, ty: float) -> float:
        return math.atan2(ty - uav.y, tx - uav.x)
