"""
main.py
-------
Entry point for the UAV Swarm Surveillance system.

Usage:
    python main.py [options]

    python main.py --episodes 300 --exec-steps 750
    python main.py --skip-training --obstacle-mobility 0.5 --obstacle-speed 8

Steps:
    1. Train search sub-agent          (PPO / LSTM)
    2. Train tracking sub-agent        (PPO / LSTM)
    3. Train obstacle-avoidance agent  (PPO / LSTM)
    4. Run full swarm execution        (all three agents + SC)
    5. Print a brief performance summary from the logged CSV data

UAV Fleet Configuration
-----------------------
Edit UAV_TYPE_COUNTS below to choose how many of each type to deploy.

  'default'  — balanced speed, sensor radius, and obstacle caution
  'searcher' — slow, wide sensor (+40 %), very cautious (+47 % prox radius)
               Designed to minimise search time.
  'trailer'  — fast, narrow sensor (-30 %), careless (-47 % prox radius)
               Designed to improve tracking continuity.

Obstacle Configuration
----------------------
obstacle_mobility_prob : fraction [0, 1] of obstacles that drift each step
obstacle_speed         : drift speed (m/s) for mobile obstacles
Both are also available as CLI flags.
"""

import argparse
import os
import time
from typing import Dict

import pandas as pd   # only used for the summary printout


# ═══════════════════════════════════════════════════════════════════════════
# FLEET CONFIGURATION — edit this dict to change the swarm composition.
# Total UAV count = sum of all values.
# ═══════════════════════════════════════════════════════════════════════════

UAV_TYPE_COUNTS: Dict[str, int] = {
    'default':  4,   # all-round effectiveness
    'searcher': 2,   # minimise search time
    'trailer':  2,   # improve tracking continuity
}

# ═══════════════════════════════════════════════════════════════════════════
# OBSTACLE CONFIGURATION — sensible defaults, overridable via CLI.
# ═══════════════════════════════════════════════════════════════════════════

OBSTACLE_MOBILITY_PROB: float = 0.3   # 30 % of obstacles drift
OBSTACLE_SPEED:         float = 6.0   # m/s drift speed


# ── CLI ───────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description='UAV Swarm Surveillance (LSTM + PPO)')

    # Training
    p.add_argument('--episodes',       type=int,   default=300,
                   help='PPO training episodes per sub-agent')
    p.add_argument('--steps',          type=int,   default=600,
                   help='Max steps per training episode')

    # Execution
    p.add_argument('--exec-steps',     type=int,   default=750,
                   help='Max steps for the execution run')
    p.add_argument('--targets',        type=int,   default=5,
                   help='Number of ground targets in execution')
    p.add_argument('--seed',           type=int,   default=42,
                   help='RNG seed for execution environment')

    # Obstacle parameters
    p.add_argument('--obstacle-mobility', type=float, default=OBSTACLE_MOBILITY_PROB,
                   metavar='PROB',
                   help='Fraction of obstacles that move [0-1] (default: '
                        f'{OBSTACLE_MOBILITY_PROB})')
    p.add_argument('--obstacle-speed',    type=float, default=OBSTACLE_SPEED,
                   metavar='MPS',
                   help=f'Speed of mobile obstacles in m/s (default: {OBSTACLE_SPEED})')

    # Paths
    p.add_argument('--skip-training',  action='store_true',
                   help='Skip training; load existing checkpoints')
    p.add_argument('--checkpoint-dir', type=str,  default='checkpoints')
    p.add_argument('--out-dir',        type=str,  default='simulation_data')
    p.add_argument('--log-dir',        type=str,  default='logs')
    return p.parse_args()


# ── pretty helpers ────────────────────────────────────────────────────────

def print_section(title: str):
    bar = '═' * 62
    print(f'\n{bar}')
    print(f'  {title}')
    print(f'{bar}')


def print_summary(out_dir: str, uav_type_counts: Dict[str, int]):
    """Read logged CSVs and print a concise performance summary."""
    print_section('EXECUTION SUMMARY')

    # Fleet breakdown
    total_uavs = sum(uav_type_counts.values())
    print(f"  Fleet ({total_uavs} UAVs):")
    for t, n in uav_type_counts.items():
        print(f"    {t:10s} x{n}")

    # Metrics
    met_path = os.path.join(out_dir, 'metrics.csv')
    if os.path.exists(met_path):
        df    = pd.read_csv(met_path)
        final = df.iloc[-1]
        peak  = df['pct_detected'].max()
        avg   = df['pct_detected'].mean()
        colls = df['n_collisions_this_step'].sum()
        print(f"\n  Total simulation steps      : {len(df)}")
        print(f"  Peak target detection       : {peak:.1f}%")
        print(f"  Mean target detection       : {avg:.1f}%")
        print(f"  Total collision events      : {int(colls)}")
        print(f"  Final n_detected / n_total  : "
              f"{int(final['n_detected_targets'])} / "
              f"{int(final['n_total_targets'])}")

    # Events
    evt_path = os.path.join(out_dir, 'events.csv')
    if os.path.exists(evt_path):
        df_evt     = pd.read_csv(evt_path)
        n_tracking = (df_evt['event_type'] == 'task_assigned').sum()
        print(f"  Tracking task assignments   : {int(n_tracking)}")

    # Target acquisition times
    tgt_path = os.path.join(out_dir, 'target_states.csv')
    if os.path.exists(tgt_path):
        df_tgt    = pd.read_csv(tgt_path)
        acq_times = (
            df_tgt[df_tgt['detected'] == 1]
            .groupby('target_id')['step']
            .min()
            .reset_index()
            .rename(columns={'step': 'first_detected_step'})
        )
        if len(acq_times):
            print(f"\n  Target acquisition times (steps):")
            for _, row in acq_times.iterrows():
                print(f"    Target {int(row['target_id'])}: "
                      f"step {int(row['first_detected_step'])}")

    # Obstacle summary
    obs_path = os.path.join(out_dir, 'obstacle_states.csv')
    if os.path.exists(obs_path):
        df_obs   = pd.read_csv(obs_path)
        n_unique = df_obs['obstacle_id'].nunique()
        n_mobile = df_obs[df_obs['mobile'] == 1]['obstacle_id'].nunique()
        print(f"\n  Obstacles: {n_unique} total, {n_mobile} mobile")

    print()
    print(f"  Output files:")
    for fname in ['uav_states.csv', 'target_states.csv',
                  'obstacle_states.csv', 'events.csv',
                  'metrics.csv', 'execution_summary.csv']:
        path = os.path.join(out_dir, fname)
        if os.path.exists(path):
            size_kb = os.path.getsize(path) / 1024
            print(f"    {fname:32s} {size_kb:8.1f} KB")


# ── main ─────────────────────────────────────────────────────────────────

def main():
    args = parse_args()
    t0   = time.time()

    print_section('UAV SWARM SURVEILLANCE — LSTM + PPO')
    total_uavs = sum(UAV_TYPE_COUNTS.values())
    print(f"  Fleet  : {UAV_TYPE_COUNTS}  (total: {total_uavs})")
    print(f"  Targets: {args.targets}")
    print(f"  Steps  : {args.exec_steps}  |  seed={args.seed}")
    print(f"  Obstacles: mobility={args.obstacle_mobility:.0%}, "
          f"speed={args.obstacle_speed} m/s")

    # ── Training ──────────────────────────────────────────────────────────
    if not args.skip_training:
        from training import (train_search_agent,
                              train_tracking_agent,
                              train_obstacle_agent)

        print_section('PHASE 1 — SEARCH SUB-AGENT TRAINING')
        train_search_agent(
            n_episodes = args.episodes,
            max_steps  = args.steps,
            save_dir   = args.checkpoint_dir,
            log_dir    = args.log_dir,
        )

        print_section('PHASE 2 — TRACKING SUB-AGENT TRAINING')
        train_tracking_agent(
            n_episodes = args.episodes,
            max_steps  = args.steps,
            save_dir   = args.checkpoint_dir,
            log_dir    = args.log_dir,
        )

        print_section('PHASE 3 — OBSTACLE AVOIDANCE SUB-AGENT TRAINING')
        train_obstacle_agent(
            n_episodes = max(args.episodes // 2, 100),
            max_steps  = min(args.steps, 400),
            save_dir   = args.checkpoint_dir,
            log_dir    = args.log_dir,
        )

        print(f'\n  Training complete ({time.time() - t0:.1f}s elapsed)')
    else:
        print('  [--skip-training] Skipping training; using existing checkpoints.')

    # ── Execution ─────────────────────────────────────────────────────────
    print_section('PHASE 4 — SWARM EXECUTION')
    from execution import run_execution

    out = run_execution(
        n_uavs                 = total_uavs,   # fallback if counts not used
        n_targets              = args.targets,
        max_steps              = args.exec_steps,
        seed                   = args.seed,
        checkpoint_dir         = args.checkpoint_dir,
        out_dir                = args.out_dir,
        uav_type_counts        = UAV_TYPE_COUNTS,
        obstacle_mobility_prob = args.obstacle_mobility,
        obstacle_speed         = args.obstacle_speed,
    )

    # ── Summary ───────────────────────────────────────────────────────────
    try:
        print_summary(out, UAV_TYPE_COUNTS)
    except Exception as e:
        print(f'  [Summary] Could not generate summary: {e}')

    print(f'\n  Total wall time: {time.time() - t0:.1f}s')
    print('  Done.\n')


if __name__ == '__main__':
    main()
