"""
visualize.py
------------
Render the UAV swarm simulation stored in simulation_data/ into an MP4 video.

Usage
-----
    python visualize.py                          # uses ./simulation_data/
    python visualize.py --data-dir my_run/       # custom data directory
    python visualize.py --fps 20 --out swarm.mp4
    python visualize.py --step-skip 2            # render every 2nd step (faster)

Layout
------
  ┌─────────────────────────────────┬──────────────────────┐
  │                                 │  STATISTICS PANEL    │
  │       ARENA  (main axes)        │  step / time         │
  │                                 │  fleet breakdown     │
  │  obstacles  targets  UAVs       │  detection bar       │
  │  sensor rings  heading arrows   │  tracking count      │
  │  search-area rectangles         │  collision counter   │
  │  target↔UAV detection lines     │  mean speed          │
  │                                 │  sub-agent pie       │
  │                                 │  speed timeline      │
  │                                 │  detection timeline  │
  └─────────────────────────────────┴──────────────────────┘

Arena elements
--------------
  Obstacles      grey squares   (mobile ones outlined in orange)
  UAVs           colour-coded by type; arrow shows heading
                   default  → steel-blue   ■
                   searcher → forest-green ■  (larger sensor ring)
                   trailer  → crimson      ■  (smaller sensor ring)
  Task overlay   search: UAV colour, dashed ring  |  tracking: bright yellow
  Sensor circles semi-transparent filled circle per UAV
  Targets        white star  (undetected)  /  bright-orange star (detected)
  Detection line thin green line from UAV to its tracked target
  Trails         last 30 positions of each UAV and target (fading)

Statistics panel (right column, 3 sub-axes)
-------------------------------------------
  Top    : current-step numbers (text block)
  Middle : detection % over time (line chart)
  Bottom : mean UAV speed over time (line chart)

Data format assumptions (matched exactly to logger.py output)
-------------------------------------------------------------
  uav_states.csv     step, uav_id, uav_type, x, y, heading_deg, speed,
                     task, active_subagent, target_id (float/NaN when empty),
                     search_area_x0/y0/x1/y1 (float/NaN), reward, collision
  target_states.csv  step, target_id, x, y, vx, vy, detected, assigned_uav (float/NaN)
  obstacle_states.csv step, obstacle_id, x, y, vx, vy, size, mobile
  metrics.csv        step, n_search_uavs, n_tracking_uavs, n_detected_targets,
                     n_total_targets, pct_detected, n_collisions_this_step, mean_uav_speed
  events.csv         step, event_type, uav_id, target_id, task_type, detail
"""

import argparse
import os
import sys
import math
import collections
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from matplotlib.animation import FuncAnimation, FFMpegWriter
from matplotlib.patches import FancyArrowPatch, Rectangle, Circle, FancyBboxPatch
import matplotlib.patheffects as pe


# ── constants ──────────────────────────────────────────────────────────────
AREA_SIZE      = 6000.0     # must match environment.py
HALF           = AREA_SIZE / 2.0
TRAIL_LEN      = 40         # frames of position trail to keep
ARROW_LEN      = 220        # heading-arrow length in world units
SENSOR_ALPHA   = 0.06       # sensor-circle fill opacity

# UAV type visual properties
UAV_STYLE: Dict[str, dict] = {
    'default':  {'color': '#4A90D9', 'marker': 's', 'ms': 10,
                 'sensor_color': '#4A90D9', 'sensor_r': 400.0,
                 'label': 'Default'},
    'searcher': {'color': '#2ECC71', 'marker': '^', 'ms': 11,
                 'sensor_color': '#2ECC71', 'sensor_r': 560.0,
                 'label': 'Searcher'},
    'trailer':  {'color': '#E74C3C', 'marker': 'D', 'ms': 10,
                 'sensor_color': '#E74C3C', 'sensor_r': 280.0,
                 'label': 'Trailer'},
}
# Fallback for unknown types
UAV_STYLE_DEFAULT = {'color': '#AAAAAA', 'marker': 'o', 'ms': 9,
                     'sensor_color': '#AAAAAA', 'sensor_r': 400.0,
                     'label': '?'}

TARGET_COLOR_UNDETECTED = '#FFFFFF'
TARGET_COLOR_DETECTED   = '#FF8C00'
OBSTACLE_COLOR_STATIC   = '#607080'
OBSTACLE_COLOR_MOBILE   = '#D35400'
DETECTION_LINE_COLOR    = '#00FF88'
BG_COLOR                = '#0D1117'   # dark background
ARENA_COLOR             = '#161B22'
GRID_COLOR              = '#21262D'
TEXT_COLOR              = '#E6EDF3'
STAT_BG                 = '#161B22'

SUBAGENT_COLORS = {
    'search':   '#4A90D9',
    'tracking': '#F1C40F',
    'obstacle': '#E74C3C',
}


# ── data loading ───────────────────────────────────────────────────────────

def load_data(data_dir: str) -> dict:
    """Load all CSVs into DataFrames, validate columns, return dict."""

    def _load(fname, required_cols):
        path = os.path.join(data_dir, fname)
        if not os.path.exists(path):
            sys.exit(f"[Viz] ERROR: {path} not found. Run the simulation first.")
        df = pd.read_csv(path)
        missing = set(required_cols) - set(df.columns)
        if missing:
            sys.exit(f"[Viz] ERROR: {fname} missing columns: {missing}")
        return df

    uav = _load('uav_states.csv',
                ['step','uav_id','uav_type','x','y','heading_deg','speed',
                 'task','active_subagent','target_id','collision'])
    tgt = _load('target_states.csv',
                ['step','target_id','x','y','vx','vy','detected','assigned_uav'])
    obs = _load('obstacle_states.csv',
                ['step','obstacle_id','x','y','vx','vy','size','mobile'])
    met = _load('metrics.csv',
                ['step','n_search_uavs','n_tracking_uavs','n_detected_targets',
                 'n_total_targets','pct_detected','n_collisions_this_step','mean_uav_speed'])
    evt = _load('events.csv',
                ['step','event_type','uav_id','target_id','task_type','detail'])

    # Coerce types that pandas may leave as float due to empty-string blanks
    uav['target_id']      = pd.to_numeric(uav['target_id'],      errors='coerce')
    tgt['assigned_uav']   = pd.to_numeric(tgt['assigned_uav'],   errors='coerce')

    steps       = sorted(uav['step'].unique())
    n_uavs      = uav['uav_id'].nunique()
    n_targets   = tgt['target_id'].nunique()
    n_obstacles = obs['obstacle_id'].nunique()
    total_steps = len(steps)

    # Pre-index by step for fast per-frame lookup
    uav_by_step = {s: g.reset_index(drop=True) for s, g in uav.groupby('step')}
    tgt_by_step = {s: g.reset_index(drop=True) for s, g in tgt.groupby('step')}
    obs_by_step = {s: g.reset_index(drop=True) for s, g in obs.groupby('step')}
    met_by_step = {s: g.iloc[0]               for s, g in met.groupby('step')}

    # Event set for quick lookup: step -> list[event_type]
    evt_by_step: Dict[int, List[str]] = collections.defaultdict(list)
    for _, row in evt.iterrows():
        try:
            evt_by_step[int(row['step'])].append(str(row['event_type']))
        except (ValueError, TypeError):
            pass

    # Cumulative collision count (running sum)
    met_sorted = met.sort_values('step')
    met_sorted = met_sorted.copy()
    met_sorted['cumulative_collisions'] = met_sorted['n_collisions_this_step'].cumsum()
    met_by_step_full = met_sorted.set_index('step')

    # Per-UAV type counts from step 0
    step0 = uav_by_step[steps[0]]
    type_counts = step0.groupby('uav_type')['uav_id'].count().to_dict()

    print(f"[Viz] Loaded: {total_steps} steps | {n_uavs} UAVs | "
          f"{n_targets} targets | {n_obstacles} obstacles")
    print(f"[Viz] Fleet: {type_counts}")

    return {
        'uav_by_step':      uav_by_step,
        'tgt_by_step':      tgt_by_step,
        'obs_by_step':      obs_by_step,
        'met_by_step':      met_by_step,
        'met_by_step_full': met_by_step_full,
        'evt_by_step':      evt_by_step,
        'steps':            steps,
        'n_uavs':           n_uavs,
        'n_targets':        n_targets,
        'n_obstacles':      n_obstacles,
        'total_steps':      total_steps,
        'type_counts':      type_counts,
        'met_full':         met_sorted,
    }


# ── figure setup ───────────────────────────────────────────────────────────

def build_figure():
    """
    Create a 16×9 figure split into:
      left  (col 0, width 2): arena
      right (col 1, width 1): 3 stat sub-axes stacked
    """
    fig = plt.figure(figsize=(18, 10), facecolor=BG_COLOR)
    fig.subplots_adjust(left=0.02, right=0.98, top=0.95, bottom=0.05,
                        wspace=0.06)

    gs = fig.add_gridspec(3, 2, width_ratios=[2.1, 1],
                          height_ratios=[1, 1, 1],
                          hspace=0.38)

    ax_arena = fig.add_subplot(gs[:, 0])   # full left column
    ax_text  = fig.add_subplot(gs[0, 1])   # top-right: live text stats
    ax_det   = fig.add_subplot(gs[1, 1])   # mid-right: detection timeline
    ax_spd   = fig.add_subplot(gs[2, 1])   # bot-right: speed timeline

    # Arena styling
    ax_arena.set_facecolor(ARENA_COLOR)
    ax_arena.set_xlim(-HALF, HALF)
    ax_arena.set_ylim(-HALF, HALF)
    ax_arena.set_aspect('equal')
    ax_arena.tick_params(colors=TEXT_COLOR, labelsize=7)
    for spine in ax_arena.spines.values():
        spine.set_edgecolor('#30363D')
    # Grid
    for v in np.arange(-HALF, HALF + 1, 1000):
        ax_arena.axvline(v, color=GRID_COLOR, lw=0.4, zorder=0)
        ax_arena.axhline(v, color=GRID_COLOR, lw=0.4, zorder=0)
    ax_arena.set_title('UAV Swarm Ground Surveillance',
                       color=TEXT_COLOR, fontsize=13, pad=6, fontweight='bold')
    ax_arena.set_xlabel('x (m)', color=TEXT_COLOR, fontsize=8)
    ax_arena.set_ylabel('y (m)', color=TEXT_COLOR, fontsize=8)

    # Stat axes styling
    for ax in (ax_text, ax_det, ax_spd):
        ax.set_facecolor(STAT_BG)
        for spine in ax.spines.values():
            spine.set_edgecolor('#30363D')
        ax.tick_params(colors=TEXT_COLOR, labelsize=7)

    ax_text.axis('off')

    ax_det.set_title('Target Detection %', color=TEXT_COLOR, fontsize=9, pad=3)
    ax_det.set_xlabel('Step', color=TEXT_COLOR, fontsize=7)
    ax_det.set_ylabel('%', color=TEXT_COLOR, fontsize=7)
    ax_det.set_ylim(-5, 105)
    ax_det.set_xlim(0, 1)
    ax_det.yaxis.label.set_color(TEXT_COLOR)
    ax_det.xaxis.label.set_color(TEXT_COLOR)

    ax_spd.set_title('Mean UAV Speed (m/s)', color=TEXT_COLOR, fontsize=9, pad=3)
    ax_spd.set_xlabel('Step', color=TEXT_COLOR, fontsize=7)
    ax_spd.set_ylabel('m/s', color=TEXT_COLOR, fontsize=7)
    ax_spd.yaxis.label.set_color(TEXT_COLOR)
    ax_spd.xaxis.label.set_color(TEXT_COLOR)

    # Legend on arena
    legend_handles = []
    for tname, style in UAV_STYLE.items():
        legend_handles.append(
            mlines.Line2D([], [], color=style['color'],
                          marker=style['marker'], linestyle='None',
                          markersize=8, label=f"UAV-{style['label']}")
        )
    legend_handles += [
        mlines.Line2D([], [], color=TARGET_COLOR_UNDETECTED,
                      marker='*', linestyle='None', markersize=9,
                      label='Target (undetected)'),
        mlines.Line2D([], [], color=TARGET_COLOR_DETECTED,
                      marker='*', linestyle='None', markersize=9,
                      label='Target (tracked)'),
        mpatches.Patch(color=OBSTACLE_COLOR_STATIC,   label='Obstacle (static)'),
        mpatches.Patch(color=OBSTACLE_COLOR_MOBILE,   label='Obstacle (mobile)'),
        mlines.Line2D([], [], color=DETECTION_LINE_COLOR,
                      linewidth=1.2, label='Detection link'),
    ]
    leg = ax_arena.legend(handles=legend_handles,
                          loc='lower left', fontsize=6.5,
                          facecolor='#21262D', edgecolor='#30363D',
                          labelcolor=TEXT_COLOR, framealpha=0.85,
                          ncol=2)

    return fig, ax_arena, ax_text, ax_det, ax_spd


# ── artist builders (called once, updated each frame) ─────────────────────

def init_arena_artists(ax_arena, data):
    """
    Pre-create all matplotlib artists that will be updated each frame.
    Returns a dict of artist references.
    """
    n_uavs      = data['n_uavs']
    n_targets   = data['n_targets']
    n_obstacles = data['n_obstacles']

    artists = {}

    # ── Obstacle squares ──────────────────────────────────────────────────
    # One Rectangle per obstacle; position updated each frame.
    # We don't know type until step 0, so we use placeholder colours.
    obs_patches = []
    for _ in range(n_obstacles):
        patch = Rectangle((0, 0), 1, 1,
                           linewidth=1.2, edgecolor='#AAAAAA',
                           facecolor=OBSTACLE_COLOR_STATIC,
                           alpha=0.85, zorder=2)
        ax_arena.add_patch(patch)
        obs_patches.append(patch)
    artists['obs_patches'] = obs_patches

    # ── UAV sensor circles ────────────────────────────────────────────────
    uav_sensors = []
    for _ in range(n_uavs):
        circ = Circle((0, 0), 1,
                      edgecolor='#AAAAAA', facecolor='#AAAAAA',
                      linewidth=0.6, alpha=SENSOR_ALPHA, zorder=3)
        ax_arena.add_patch(circ)
        uav_sensors.append(circ)
    artists['uav_sensors'] = uav_sensors

    # ── Search-area rectangles (dashed border, no fill) ───────────────────
    uav_search_rects = []
    for _ in range(n_uavs):
        rect = Rectangle((0, 0), 1, 1,
                         linewidth=0.8, linestyle='--',
                         edgecolor='#AAAAAA', facecolor='none',
                         alpha=0.35, zorder=2)
        ax_arena.add_patch(rect)
        uav_search_rects.append(rect)
    artists['uav_search_rects'] = uav_search_rects

    # ── UAV trails (deque per UAV) ────────────────────────────────────────
    uav_trails = []
    for _ in range(n_uavs):
        line, = ax_arena.plot([], [], '-', lw=0.9, alpha=0.4, zorder=4)
        uav_trails.append(line)
    artists['uav_trails'] = uav_trails
    artists['uav_trail_data'] = [collections.deque(maxlen=TRAIL_LEN)
                                  for _ in range(n_uavs)]

    # ── UAV markers + heading arrows ──────────────────────────────────────
    uav_markers = []
    uav_arrows  = []
    for _ in range(n_uavs):
        pt, = ax_arena.plot([], [], marker='s', markersize=10,
                            color='white', zorder=6, linestyle='None')
        uav_markers.append(pt)
        arr = FancyArrowPatch((0, 0), (0, 0),
                              arrowstyle='->', color='white',
                              linewidth=1.4, mutation_scale=10, zorder=7)
        ax_arena.add_patch(arr)
        uav_arrows.append(arr)
    artists['uav_markers'] = uav_markers
    artists['uav_arrows']  = uav_arrows

    # ── UAV id labels ─────────────────────────────────────────────────────
    uav_labels = []
    for _ in range(n_uavs):
        txt = ax_arena.text(0, 0, '', fontsize=6, color=TEXT_COLOR,
                            ha='center', va='bottom', zorder=8,
                            fontweight='bold')
        uav_labels.append(txt)
    artists['uav_labels'] = uav_labels

    # ── Target trails ─────────────────────────────────────────────────────
    tgt_trails = []
    for _ in range(n_targets):
        line, = ax_arena.plot([], [], '-', lw=0.6, alpha=0.3,
                              color='#FF8C00', zorder=4)
        tgt_trails.append(line)
    artists['tgt_trails'] = tgt_trails
    artists['tgt_trail_data'] = [collections.deque(maxlen=TRAIL_LEN)
                                   for _ in range(n_targets)]

    # ── Target markers ────────────────────────────────────────────────────
    tgt_markers = []
    for _ in range(n_targets):
        pt, = ax_arena.plot([], [], marker='*', markersize=12,
                            color=TARGET_COLOR_UNDETECTED, zorder=6,
                            linestyle='None',
                            markeredgecolor='#555555', markeredgewidth=0.5)
        tgt_markers.append(pt)
    artists['tgt_markers'] = tgt_markers

    # ── Detection lines (UAV → tracked target) ────────────────────────────
    det_lines = []
    for _ in range(n_uavs):
        line, = ax_arena.plot([], [], '-',
                              color=DETECTION_LINE_COLOR,
                              lw=1.0, alpha=0.7, zorder=5)
        det_lines.append(line)
    artists['det_lines'] = det_lines

    # ── Step / time label ─────────────────────────────────────────────────
    artists['step_label'] = ax_arena.text(
        0.01, 0.985, '', transform=ax_arena.transAxes,
        color=TEXT_COLOR, fontsize=9, va='top', ha='left',
        fontweight='bold',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='#21262D',
                  edgecolor='#30363D', alpha=0.9)
    )

    # ── Event flash label (disappears after a few frames) ─────────────────
    artists['event_label'] = ax_arena.text(
        0.5, 0.015, '', transform=ax_arena.transAxes,
        color='#F1C40F', fontsize=8, va='bottom', ha='center',
        fontweight='bold', alpha=0.0
    )
    artists['event_flash_timer'] = [0]

    return artists


# ── frame update ───────────────────────────────────────────────────────────

def make_update_fn(data, artists, ax_text, ax_det, ax_spd):
    """Return the FuncAnimation update callable."""

    steps        = data['steps']
    uav_by_step  = data['uav_by_step']
    tgt_by_step  = data['tgt_by_step']
    obs_by_step  = data['obs_by_step']
    met_by_step  = data['met_by_step']
    met_full     = data['met_full']
    evt_by_step  = data['evt_by_step']
    type_counts  = data['type_counts']

    # Pre-build cumulative collision array for all steps
    cum_col = met_full.set_index('step')['cumulative_collisions']

    # Timeline data (accumulated as animation progresses)
    timeline_steps = []
    timeline_det   = []
    timeline_spd   = []

    # Text stats object list (cleared/rebuilt each frame to avoid accumulation)
    text_objs = []

    # stat chart lines (created once)
    det_line, = ax_det.plot([], [], color='#F1C40F', lw=1.4)
    spd_line, = ax_spd.plot([], [], color='#4A90D9', lw=1.4)
    ax_det.axhline(100, color='#30363D', lw=0.6, ls='--')
    ax_spd.fill_between([], [], alpha=0.15, color='#4A90D9')

    def update(frame_idx: int):
        step = steps[frame_idx]
        uav_df = uav_by_step.get(step, pd.DataFrame())
        tgt_df = tgt_by_step.get(step, pd.DataFrame())
        obs_df = obs_by_step.get(step, pd.DataFrame())
        met    = met_by_step.get(step)

        if uav_df.empty or met is None:
            return []

        # ── Obstacles ────────────────────────────────────────────────────
        obs_patches = artists['obs_patches']
        for row in obs_df.itertuples():
            oid   = int(row.obstacle_id)
            if oid >= len(obs_patches):
                continue
            patch = obs_patches[oid]
            s     = float(row.size)
            patch.set_xy((float(row.x) - s, float(row.y) - s))
            patch.set_width(2 * s)
            patch.set_height(2 * s)
            is_mobile = int(row.mobile) == 1
            patch.set_facecolor(OBSTACLE_COLOR_MOBILE if is_mobile
                                else OBSTACLE_COLOR_STATIC)
            patch.set_edgecolor('#FF8C00' if is_mobile else '#8A9BAE')

        # ── UAVs ─────────────────────────────────────────────────────────
        uav_trail_data  = artists['uav_trail_data']
        tgt_trail_data  = artists['tgt_trail_data']

        # Build target position lookup for this step
        tgt_pos: Dict[int, Tuple[float, float]] = {}
        for row in tgt_df.itertuples():
            tgt_pos[int(row.target_id)] = (float(row.x), float(row.y))

        # Build UAV position lookup for detection lines
        uav_pos_by_id: Dict[int, Tuple[float, float]] = {}

        for row in uav_df.itertuples():
            uid   = int(row.uav_id)
            ux, uy = float(row.x), float(row.y)
            uav_pos_by_id[uid] = (ux, uy)
            utype = str(row.uav_type)
            style = UAV_STYLE.get(utype, UAV_STYLE_DEFAULT)
            col   = style['color']
            sr    = style['sensor_r']

            # Trail
            if uid < len(uav_trail_data):
                uav_trail_data[uid].append((ux, uy))
                xs = [p[0] for p in uav_trail_data[uid]]
                ys = [p[1] for p in uav_trail_data[uid]]
                # Fade: alpha gradient done via single line (simplified)
                artists['uav_trails'][uid].set_data(xs, ys)
                artists['uav_trails'][uid].set_color(col)

            # Sensor circle
            circ = artists['uav_sensors'][uid]
            circ.set_center((ux, uy))
            circ.set_radius(sr)
            circ.set_facecolor(col)
            circ.set_edgecolor(col)
            # Brighter ring when tracking
            task = str(row.task)
            if task == 'tracking':
                circ.set_alpha(SENSOR_ALPHA * 2.0)
                circ.set_linewidth(1.5)
            else:
                circ.set_alpha(SENSOR_ALPHA)
                circ.set_linewidth(0.5)

            # Search area rect
            rect = artists['uav_search_rects'][uid]
            try:
                x0 = float(row.search_area_x0)
                y0 = float(row.search_area_y0)
                x1 = float(row.search_area_x1)
                y1 = float(row.search_area_y1)
                if not (math.isnan(x0) or math.isnan(y0)):
                    rect.set_xy((x0, y0))
                    rect.set_width(x1 - x0)
                    rect.set_height(y1 - y0)
                    rect.set_edgecolor(col)
                    rect.set_visible(task == 'search')
                else:
                    rect.set_visible(False)
            except (AttributeError, ValueError):
                rect.set_visible(False)

            # Marker
            mk = artists['uav_markers'][uid]
            mk.set_data([ux], [uy])
            mk.set_color(col)
            mk.set_marker(style['marker'])
            mk.set_markersize(style['ms'])
            # Collision flash
            if int(row.collision) == 1:
                mk.set_markeredgecolor('#FF0000')
                mk.set_markeredgewidth(2.5)
            else:
                mk.set_markeredgecolor('#FFFFFF')
                mk.set_markeredgewidth(0.8)

            # Heading arrow
            heading_rad = math.radians(float(row.heading_deg))
            dx = ARROW_LEN * math.cos(heading_rad)
            dy = ARROW_LEN * math.sin(heading_rad)
            arr = artists['uav_arrows'][uid]
            arr.set_positions((ux, uy), (ux + dx, uy + dy))
            arr.set_color(col)

            # UAV label: "U0\ntype\nsubagent"
            subagent = str(row.active_subagent)
            sub_sym  = {'search': '🔍', 'tracking': '🎯', 'obstacle': '⚠'}.get(subagent, subagent)
            artists['uav_labels'][uid].set_position((ux, uy + sr * 0.18))
            artists['uav_labels'][uid].set_text(f'U{uid}')
            artists['uav_labels'][uid].set_color(col)

            # Detection line
            det_line_art = artists['det_lines'][uid]
            try:
                tid_val = row.target_id
                if not (isinstance(tid_val, float) and math.isnan(tid_val)):
                    tid = int(tid_val)
                    if tid in tgt_pos and task == 'tracking':
                        tx, ty = tgt_pos[tid]
                        det_line_art.set_data([ux, tx], [uy, ty])
                    else:
                        det_line_art.set_data([], [])
                else:
                    det_line_art.set_data([], [])
            except (TypeError, ValueError):
                det_line_art.set_data([], [])

        # ── Targets ───────────────────────────────────────────────────────
        for row in tgt_df.itertuples():
            tid  = int(row.target_id)
            tx   = float(row.x)
            ty   = float(row.y)
            det  = int(row.detected)

            if tid < len(tgt_trail_data):
                tgt_trail_data[tid].append((tx, ty))
                xs = [p[0] for p in tgt_trail_data[tid]]
                ys = [p[1] for p in tgt_trail_data[tid]]
                artists['tgt_trails'][tid].set_data(xs, ys)

            if tid < len(artists['tgt_markers']):
                mk = artists['tgt_markers'][tid]
                mk.set_data([tx], [ty])
                if det:
                    mk.set_color(TARGET_COLOR_DETECTED)
                    mk.set_markersize(13)
                    mk.set_markeredgecolor('#FF4500')
                    mk.set_markeredgewidth(1.2)
                else:
                    mk.set_color(TARGET_COLOR_UNDETECTED)
                    mk.set_markersize(11)
                    mk.set_markeredgecolor('#777777')
                    mk.set_markeredgewidth(0.5)

        # ── Step label ────────────────────────────────────────────────────
        artists['step_label'].set_text(f'Step {step:4d}')

        # ── Event flash ───────────────────────────────────────────────────
        evts = evt_by_step.get(step, [])
        timer = artists['event_flash_timer']
        if evts:
            msg = ' | '.join(evts[:3])
            artists['event_label'].set_text(msg)
            artists['event_label'].set_alpha(1.0)
            timer[0] = 12
        else:
            if timer[0] > 0:
                timer[0] -= 1
                artists['event_label'].set_alpha(timer[0] / 12.0)
            else:
                artists['event_label'].set_alpha(0.0)

        # ── Statistics text panel ─────────────────────────────────────────
        for t in text_objs:
            t.remove()
        text_objs.clear()

        n_search   = int(met['n_search_uavs'])
        n_tracking = int(met['n_tracking_uavs'])
        n_det      = int(met['n_detected_targets'])
        n_tot      = int(met['n_total_targets'])
        pct        = float(met['pct_detected'])
        col_step   = int(met['n_collisions_this_step'])
        spd        = float(met['mean_uav_speed'])
        cum_c      = int(cum_col.get(step, 0))

        # Fleet type counts (static)
        fleet_str = '  '.join(f"{k}×{v}" for k, v in type_counts.items())

        lines = [
            ('LIVE STATISTICS', '#E6EDF3', 11, True),
            ('', '#888888', 1, False),
            (f'Step          {step:>6d}',       TEXT_COLOR, 9, False),
            (f'Fleet         {fleet_str}',       '#AAAAAA', 8, False),
            ('', '#888888', 1, False),
            (f'UAVs searching    {n_search:>3d}', '#4A90D9', 9, False),
            (f'UAVs tracking     {n_tracking:>3d}', '#F1C40F', 9, False),
            ('', '#888888', 1, False),
            (f'Targets detected  {n_det:>2d}/{n_tot:<2d}', TARGET_COLOR_DETECTED, 10, True),
            (f'Detection rate   {pct:>5.1f}%',   '#2ECC71', 9, False),
            ('', '#888888', 1, False),
            (f'Collisions (step) {col_step:>3d}',  '#E74C3C', 9, False),
            (f'Collisions (total){cum_c:>3d}',     '#FF7043', 9, False),
            ('', '#888888', 1, False),
            (f'Mean UAV speed  {spd:>6.1f} m/s',  '#4A90D9', 9, False),
        ]

        # Sub-agent breakdown from current uav_df
        sa_counts = uav_df['active_subagent'].value_counts().to_dict()
        lines.append(('', '#888888', 1, False))
        lines.append(('Sub-agents active:', '#AAAAAA', 8, False))
        for sa_name, sa_col in SUBAGENT_COLORS.items():
            cnt = sa_counts.get(sa_name, 0)
            lines.append((f'  {sa_name:<10s} {cnt:>2d}', sa_col, 8, False))

        y_pos = 0.97
        for text, color, fsize, bold in lines:
            if text == '':
                y_pos -= 0.018
                continue
            t = ax_text.text(0.04, y_pos, text,
                             transform=ax_text.transAxes,
                             color=color, fontsize=fsize,
                             va='top', ha='left',
                             fontweight='bold' if bold else 'normal',
                             fontfamily='monospace')
            text_objs.append(t)
            y_pos -= 0.055 if fsize >= 10 else 0.048

        # ── Timeline charts ───────────────────────────────────────────────
        timeline_steps.append(step)
        timeline_det.append(pct)
        timeline_spd.append(spd)

        xs = timeline_steps
        if len(xs) > 1:
            ax_det.set_xlim(xs[0], max(xs[-1], xs[0] + 1))
            det_line.set_data(xs, timeline_det)

            ax_spd.set_xlim(xs[0], max(xs[-1], xs[0] + 1))
            spd_line.set_data(xs, timeline_spd)
            if max(timeline_spd) > 0:
                ax_spd.set_ylim(0, max(timeline_spd) * 1.15)

        # Vertical cursor on charts
        for ax_c, line_c in [(ax_det, det_line), (ax_spd, spd_line)]:
            # Remove old cursor lines
            for child in ax_c.get_lines():
                if getattr(child, '_is_cursor', False):
                    child.remove()
            cur = ax_c.axvline(step, color='#F1C40F', lw=0.8, alpha=0.6)
            cur._is_cursor = True

        return []  # FuncAnimation doesn't strictly need return list with blit=False

    return update


# ── main render ────────────────────────────────────────────────────────────

def render(data_dir: str, out_path: str, fps: int, step_skip: int,
           dpi: int = 120):

    data    = load_data(data_dir)
    steps   = data['steps']

    # Sub-sample steps
    steps_to_render = steps[::step_skip]
    total_frames    = len(steps_to_render)
    print(f"[Viz] Rendering {total_frames} frames at {fps} fps → {out_path}")

    fig, ax_arena, ax_text, ax_det, ax_spd = build_figure()
    artists = init_arena_artists(ax_arena, data)
    update  = make_update_fn(data, artists, ax_text, ax_det, ax_spd)

    # Rebuild steps list to only the sub-sampled ones
    data_sub          = dict(data)
    data_sub['steps'] = steps_to_render

    # Re-create update with sub-sampled steps
    update2 = make_update_fn(data_sub, artists, ax_text, ax_det, ax_spd)

    # Set timeline x-axis limits from full range
    last_step = steps[-1]
    ax_det.set_xlim(0, last_step + 1)
    ax_spd.set_xlim(0, last_step + 1)
    # Speed y-limit: use max from metrics
    max_spd = data['met_full']['mean_uav_speed'].max()
    ax_spd.set_ylim(0, max_spd * 1.2 + 5)

    def _update(frame_idx):
        update2(frame_idx)
        if frame_idx % max(1, total_frames // 20) == 0:
            pct_done = frame_idx / total_frames * 100
            print(f"  … {pct_done:5.1f}%  (frame {frame_idx}/{total_frames})",
                  end='\r', flush=True)

    anim = FuncAnimation(fig, _update,
                         frames=total_frames,
                         interval=1000 / fps,
                         blit=False)

    writer = FFMpegWriter(fps=fps, metadata={'title': 'UAV Swarm Surveillance'},
                          bitrate=2400,
                          extra_args=['-vcodec', 'libx264',
                                      '-pix_fmt', 'yuv420p'])
    anim.save(out_path, writer=writer, dpi=dpi)
    print(f"\n[Viz] Saved: {out_path}  "
          f"({os.path.getsize(out_path) / 1024 / 1024:.1f} MB)")
    plt.close(fig)


# ── CLI ────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description='Render UAV swarm simulation data to MP4')
    p.add_argument('--data-dir',   default='simulation_data',
                   help='Directory containing the simulation CSV files')
    p.add_argument('--out',        default='swarm_simulation.mp4',
                   help='Output MP4 filename')
    p.add_argument('--fps',        type=int, default=15,
                   help='Frames per second in output video (default: 15)')
    p.add_argument('--step-skip',  type=int, default=1,
                   help='Render every N-th step (default: 1 = all steps)')
    p.add_argument('--dpi',        type=int, default=120,
                   help='Resolution DPI (default: 120)')
    return p.parse_args()


if __name__ == '__main__':
    args = parse_args()
    render(
        data_dir  = args.data_dir,
        out_path  = args.out,
        fps       = args.fps,
        step_skip = args.step_skip,
        dpi       = args.dpi,
    )
